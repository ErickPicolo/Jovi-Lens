import base64
import hashlib
import html
import io
import json
import os
import queue
import re
import secrets
import socket
import statistics
import threading
import time
import unicodedata
import webbrowser
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from difflib import SequenceMatcher
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, quote, urlparse
from tkinter import filedialog, messagebox, simpledialog
from tkinter import font as tkfont
import tkinter as tk

import requests
from PIL import Image, ImageDraw, ImageFilter, ImageOps, ImageTk

try:
    import cv2
except ImportError:
    cv2 = None

PASTA_BASE = os.path.dirname(os.path.abspath(__file__))
ARQUIVO_DADOS = os.path.join(PASTA_BASE, "jovi_lens_dados.json")
ARQUIVO_CONFIG = os.path.join(PASTA_BASE, "jovi_lens_config.json")

URL_ML_BUSCA = "https://api.mercadolibre.com/sites/MLB/search"
URL_ML_TOKEN = "https://api.mercadolibre.com/oauth/token"
URL_SERPAPI = "https://serpapi.com/search.json"
URL_SERPER = "https://google.serper.dev/shopping"
URL_GEMINI = "https://generativelanguage.googleapis.com/v1beta"
CABECALHOS = {
    "User-Agent": "JoviLens/1.0 (projeto academico)",
    "Accept": "application/json",
}
TIMEOUT = 15
LIMITE_ALERTAS = 100
QUEDA_MINIMA_PERCENTUAL = 5.0
INTERVALO_MONITORAMENTO_MS = 15 * 60 * 1000

COR_FUNDO = "#0b0f19"
COR_PAINEL = "#141a2a"
COR_DESTAQUE = "#4f8cff"
COR_TEXTO = "#f3f4f6"
COR_SUAVE = "#8b93a7"


TRAVA_ARQUIVO = threading.Lock()


class ErroBusca(Exception):
    pass


class ErroIdentificacao(Exception):
    pass


def formatar_preco(valor):
    if valor is None:
        return "-"
    texto = f"{valor:,.2f}"
    return "R$ " + texto.replace(",", "X").replace(".", ",").replace("X", ".")


def agora_texto():
    return datetime.now().strftime("%d/%m/%Y %H:%M")


CHAVES_CONFIG = (
    "gemini_key",
    "gemini_modelo",
    "serper_key",
    "ml_client_id",
    "ml_client_secret",
    "serpapi_key",
)


def chave_valida(valor):
    valor = str(valor or "").strip()
    return valor if len(valor) >= 16 and "COLE" not in valor.upper() else ""


def carregar_config():
    config = {chave: "" for chave in CHAVES_CONFIG}
    incompleto = False
    try:
        with open(ARQUIVO_CONFIG, "r", encoding="utf-8") as arquivo:
            lido = json.load(arquivo)
        if isinstance(lido, dict):
            incompleto = any(chave not in lido for chave in CHAVES_CONFIG)
            for chave in CHAVES_CONFIG:
                config[chave] = str(lido.get(chave, ""))
        else:
            incompleto = True
    except FileNotFoundError:
        incompleto = True
    except (OSError, json.JSONDecodeError):
        pass
    if incompleto:
        try:
            with open(ARQUIVO_CONFIG, "w", encoding="utf-8") as arquivo:
                json.dump(config, arquivo, indent=2, ensure_ascii=False)
        except OSError:
            pass
    ambiente = {
        "ml_client_id": "ML_CLIENT_ID",
        "ml_client_secret": "ML_CLIENT_SECRET",
        "gemini_key": "GEMINI_KEY",
        "serper_key": "SERPER_KEY",
        "serpapi_key": "SERPAPI_KEY",
    }
    for chave, variavel in ambiente.items():
        config[chave] = chave_valida(os.environ.get(variavel) or config[chave])
    config["gemini_modelo"] = (
        os.environ.get("GEMINI_MODELO") or config["gemini_modelo"].strip()
    )
    return config


def carregar_dados():
    vazio = {"favoritos": [], "alertas": []}
    try:
        with open(ARQUIVO_DADOS, "r", encoding="utf-8") as arquivo:
            dados = json.load(arquivo)
        if not isinstance(dados, dict):
            raise ValueError("estrutura inválida")
        dados.setdefault("favoritos", [])
        dados.setdefault("alertas", [])
        return dados
    except FileNotFoundError:
        return vazio
    except (OSError, ValueError):
        try:
            os.replace(ARQUIVO_DADOS, ARQUIVO_DADOS + ".corrompido")
        except OSError:
            pass
        return vazio


def salvar_dados(dados):
    temporario = ARQUIVO_DADOS + ".tmp"
    try:
        with TRAVA_ARQUIVO:
            with open(temporario, "w", encoding="utf-8") as arquivo:
                json.dump(dados, arquivo, indent=2, ensure_ascii=False)
            os.replace(temporario, ARQUIVO_DADOS)
        return True
    except OSError:
        return False


class GerenciadorToken:
    def __init__(self, client_id, client_secret):
        self.client_id = client_id
        self.client_secret = client_secret
        self.token = None
        self.expira_em = 0.0

    def disponivel(self):
        return bool(self.client_id and self.client_secret)

    def obter(self):
        if not self.disponivel():
            return None
        if self.token and time.time() < self.expira_em - 60:
            return self.token
        try:
            resposta = requests.post(
                URL_ML_TOKEN,
                data={
                    "grant_type": "client_credentials",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                },
                headers=CABECALHOS,
                timeout=TIMEOUT,
            )
            resposta.raise_for_status()
            corpo = resposta.json()
            self.token = corpo["access_token"]
            self.expira_em = time.time() + int(corpo.get("expires_in", 3600))
            return self.token
        except (requests.RequestException, KeyError, ValueError) as erro:
            raise ErroBusca(f"Falha ao autenticar no Mercado Livre: {erro}") from erro


def buscar_mercado_livre(termo, limite, gerenciador_token):
    cabecalhos = dict(CABECALHOS)
    token = gerenciador_token.obter()
    if token:
        cabecalhos["Authorization"] = f"Bearer {token}"
    try:
        resposta = requests.get(
            URL_ML_BUSCA,
            params={"q": termo, "limit": limite},
            headers=cabecalhos,
            timeout=TIMEOUT,
        )
    except requests.ConnectionError:
        raise ErroBusca("Mercado Livre: sem conexão com a internet.") from None
    except requests.Timeout:
        raise ErroBusca("Mercado Livre: tempo de resposta esgotado.") from None
    except requests.RequestException as erro:
        raise ErroBusca(f"Mercado Livre: erro de rede ({erro}).") from erro

    if resposta.status_code in (401, 403):
        raise ErroBusca(
            "Mercado Livre: acesso negado. A busca exige credenciais "
            "(ml_client_id e ml_client_secret no arquivo de configuração)."
        )
    if resposta.status_code != 200:
        raise ErroBusca(
            f"Mercado Livre: resposta inesperada (HTTP {resposta.status_code})."
        )

    try:
        itens = resposta.json().get("results", [])
    except ValueError:
        raise ErroBusca("Mercado Livre: resposta inválida do servidor.") from None

    produtos = []
    for item in itens:
        preco = item.get("price")
        if preco is None:
            continue
        produtos.append(
            {
                "id": str(item.get("id", "")),
                "titulo": item.get("title", "Sem título"),
                "preco": float(preco),
                "loja": "Mercado Livre",
                "link": item.get("permalink", ""),
            }
        )
    return produtos


def gerar_id(texto):
    return hashlib.md5(texto.encode("utf-8")).hexdigest()[:16]


def converter_preco_texto(texto):
    if isinstance(texto, (int, float)):
        return float(texto)
    achado = re.search(r"\d[\d.]*(?:,\d+)?", str(texto))
    if not achado:
        return None
    numero = achado.group(0)
    if "," in numero:
        numero = numero.replace(".", "").replace(",", ".")
    elif re.fullmatch(r"\d{1,3}(\.\d{3})+", numero):
        numero = numero.replace(".", "")
    try:
        return float(numero)
    except ValueError:
        return None


def buscar_serper(termo, limite, chave):
    try:
        resposta = requests.post(
            URL_SERPER,
            json={"q": termo, "gl": "br", "hl": "pt-br", "num": limite},
            headers={"X-API-KEY": chave, "Content-Type": "application/json"},
            timeout=TIMEOUT,
        )
    except requests.ConnectionError:
        raise ErroBusca("Serper: sem conexão com a internet.") from None
    except requests.Timeout:
        raise ErroBusca("Serper: tempo de resposta esgotado.") from None
    except requests.RequestException as erro:
        raise ErroBusca(f"Serper: erro de rede ({erro}).") from erro
    if resposta.status_code in (401, 403):
        raise ErroBusca("Serper: chave inválida. Confira o valor de serper_key.")
    if resposta.status_code != 200:
        raise ErroBusca(f"Serper: resposta inesperada (HTTP {resposta.status_code}).")
    try:
        itens = resposta.json().get("shopping", [])
    except ValueError:
        raise ErroBusca("Serper: resposta inválida do servidor.") from None
    produtos = []
    for item in itens[:limite]:
        preco = converter_preco_texto(item.get("price"))
        titulo = item.get("title", "Sem título")
        loja = item.get("source", "Google Shopping")
        if not preco:
            continue
        produtos.append(
            {
                "id": gerar_id(titulo + loja),
                "titulo": titulo,
                "preco": preco,
                "loja": loja,
                "link": item.get("link", ""),
            }
        )
    return produtos


def buscar_google_shopping(termo, limite, chave):
    if not chave:
        raise ErroBusca("SerpAPI: chave não configurada.")
    try:
        resposta = requests.get(
            URL_SERPAPI,
            params={
                "engine": "google_shopping",
                "q": termo,
                "gl": "br",
                "hl": "pt-br",
                "num": limite,
                "api_key": chave,
            },
            headers=CABECALHOS,
            timeout=TIMEOUT,
        )
    except requests.ConnectionError:
        raise ErroBusca("Google Shopping: sem conexão com a internet.") from None
    except requests.Timeout:
        raise ErroBusca("Google Shopping: tempo de resposta esgotado.") from None
    except requests.RequestException as erro:
        raise ErroBusca(f"Google Shopping: erro de rede ({erro}).") from erro

    if resposta.status_code in (401, 403):
        raise ErroBusca("SerpAPI: chave inválida. Confira o valor de serpapi_key.")
    if resposta.status_code != 200:
        raise ErroBusca(f"SerpAPI: resposta inesperada (HTTP {resposta.status_code}).")
    try:
        itens = resposta.json().get("shopping_results", [])
    except ValueError:
        raise ErroBusca("Google Shopping: resposta inválida do servidor.") from None

    produtos = []
    for item in itens[:limite]:
        preco = item.get("extracted_price")
        if preco is None:
            continue
        identificador = str(
            item.get("product_id")
            or gerar_id(item.get("title", "") + item.get("source", ""))
        )
        produtos.append(
            {
                "id": identificador,
                "titulo": item.get("title", "Sem título"),
                "preco": float(preco),
                "loja": item.get("source", "Google Shopping"),
                "link": item.get("link") or item.get("product_link", ""),
            }
        )
    return produtos


URL_ML_LISTA = "https://lista.mercadolivre.com.br/"
CABECALHOS_NAVEGADOR = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "pt-BR,pt;q=0.9",
}


def limpar_html(texto):
    return html.unescape(re.sub(r"<[^>]+>", "", texto)).strip()


def identificar_id_anuncio(link, titulo):
    achado = re.search(r"MLB-?(\d+)", link)
    if achado:
        return "MLB" + achado.group(1)
    return "ml-" + gerar_id(titulo)


def percorrer_json_ld(no, saida):
    if isinstance(no, list):
        for item in no:
            percorrer_json_ld(item, saida)
    elif isinstance(no, dict):
        oferta = no.get("offers")
        if no.get("name") and oferta:
            if isinstance(oferta, list):
                oferta = oferta[0] if oferta else {}
            try:
                preco = float(oferta.get("price") or oferta.get("lowPrice"))
            except (TypeError, ValueError, AttributeError):
                preco = None
            link = str(
                no.get("url")
                or (oferta.get("url") if isinstance(oferta, dict) else "")
                or ""
            )
            if preco and link:
                saida.append(
                    {
                        "id": identificar_id_anuncio(link, no["name"]),
                        "titulo": limpar_html(str(no["name"])),
                        "preco": preco,
                        "loja": "Mercado Livre",
                        "link": link,
                    }
                )
        for valor in no.values():
            if isinstance(valor, (dict, list)):
                percorrer_json_ld(valor, saida)


def extrair_produtos_json_ld(pagina):
    produtos = []
    for bruto in re.findall(
        r"<script[^>]*application/ld\+json[^>]*>(.*?)</script>", pagina, re.S
    ):
        try:
            percorrer_json_ld(json.loads(bruto), produtos)
        except ValueError:
            continue
    return produtos


def extrair_produtos_cartoes(pagina):
    separador = (
        r'(?=<(?:li|div)[^>]*class="[^"]*(?:\bpoly-card[\s"]|ui-search-layout__item))'
    )
    produtos = []
    for bloco in re.split(separador, pagina):
        titulo = re.search(r"poly-component__title[^>]*>(.*?)</a>", bloco, re.S)
        if not titulo:
            titulo = re.search(r"<h[23][^>]*>(.*?)</h[23]>", bloco, re.S)
        link = re.search(r'href="(https?://[^"]*mercadoli[^"]*)"', bloco)
        sem_antigo = re.sub(
            r"<s[^>]*andes-money-amount--previous.*?</s>", "", bloco, flags=re.S
        )
        fracao = re.search(r"andes-money-amount__fraction[^>]*>([\d.]+)<", sem_antigo)
        if not (titulo and link and fracao):
            continue
        centavos = re.search(r"andes-money-amount__cents[^>]*>(\d+)<", sem_antigo)
        try:
            preco = int(fracao.group(1).replace(".", "")) + (
                int(centavos.group(1)) / 100 if centavos else 0
            )
        except ValueError:
            continue
        nome = limpar_html(titulo.group(1))
        produtos.append(
            {
                "id": identificar_id_anuncio(link.group(1), nome),
                "titulo": nome,
                "preco": float(preco),
                "loja": "Mercado Livre",
                "link": html.unescape(link.group(1)),
            }
        )
    return produtos


def extrair_produtos_html(pagina, limite):
    vistos = set()
    unicos = []
    for produto in extrair_produtos_cartoes(pagina) + extrair_produtos_json_ld(pagina):
        if produto["id"] in vistos:
            continue
        vistos.add(produto["id"])
        unicos.append(produto)
    return unicos[:limite]


def buscar_mercado_livre_html(termo, limite):
    url = URL_ML_LISTA + quote(termo.strip().replace(" ", "-"))
    try:
        resposta = requests.get(url, headers=CABECALHOS_NAVEGADOR, timeout=TIMEOUT)
    except requests.ConnectionError:
        raise ErroBusca("Mercado Livre (página): sem conexão com a internet.") from None
    except requests.Timeout:
        raise ErroBusca("Mercado Livre (página): tempo de resposta esgotado.") from None
    except requests.RequestException as erro:
        raise ErroBusca(f"Mercado Livre (página): erro de rede ({erro}).") from erro
    if "account-verification" in resposta.url or resposta.status_code in (
        401,
        403,
        429,
    ):
        raise ErroBusca(
            "Mercado Livre (página): acesso bloqueado temporariamente. Tente novamente em instantes."
        )
    if resposta.status_code != 200:
        raise ErroBusca(
            f"Mercado Livre (página): resposta inesperada (HTTP {resposta.status_code})."
        )
    produtos = extrair_produtos_html(resposta.text, limite)
    if not produtos:
        raise ErroBusca(
            "Mercado Livre (página): nenhum produto encontrado para esse termo."
        )
    return produtos


URL_GOOGLE_SHOPPING = "https://www.google.com/search?tbm=shop&q="
ROTULOS_LINK = {"direto": "✔ direto", "google": "Google", "busca": "sem link"}


def link_busca_alternativo(titulo, loja=""):
    return URL_GOOGLE_SHOPPING + quote(f"{titulo} {loja}".strip())


def classificar_link(link, titulo, loja):
    link = (link or "").strip()
    if not re.match(r"^https?://", link, re.IGNORECASE):
        return link_busca_alternativo(titulo, loja), "busca"
    anfitriao = urlparse(link).netloc.lower()
    if "google." in anfitriao:
        return link, "google"
    return link, "direto"


def normalizar_links(produtos):
    for produto in produtos:
        produto["link"], produto["tipo_link"] = classificar_link(
            produto.get("link"), produto["titulo"], produto.get("loja", "")
        )
    return produtos


URL_SERPER_BUSCA = "https://google.serper.dev/search"


PALAVRAS_GENERICAS_LOJA = {
    "supermercado",
    "supermercados",
    "mercado",
    "mercadinho",
    "loja",
    "lojas",
    "online",
    "drogaria",
    "drogarias",
    "farmacia",
    "farmacias",
    "casa",
    "casas",
    "comercio",
    "distribuidora",
    "atacado",
    "atacadao",
    "store",
    "shop",
    "bebidas",
    "doces",
    "salgados",
    "ltda",
    "oficial",
    "delivery",
    "emporio",
    "grupo",
    "rede",
}
PALAVRAS_GENERICAS_PRODUTO = {
    "para",
    "com",
    "sem",
    "kit",
    "lata",
    "unidade",
    "unidades",
    "caixa",
    "pack",
    "fardo",
    "original",
    "novo",
}
DOMINIOS_IGNORADOS = (
    "google.",
    "youtube.",
    "facebook.",
    "instagram.",
    "tiktok.",
    "reclameaqui.",
    "pinterest.",
    "wikipedia.",
    "buscape.",
    "zoom.com.br",
    "bing.",
    "jusbrasil.",
)


def normalizar_texto(texto):
    texto = unicodedata.normalize("NFKD", texto.lower())
    return "".join(c for c in texto if not unicodedata.combining(c))


def chaves_da_loja(loja):
    base = normalizar_texto(loja.split(" - ")[0])
    principal = re.sub(r"[^a-z0-9]", "", base.split(".")[0])
    palavras = [
        p for p in re.findall(r"[a-z0-9]{4,}", base) if p not in PALAVRAS_GENERICAS_LOJA
    ]
    return principal, palavras


def palavras_do_produto(titulo):
    return [
        p
        for p in re.findall(r"[a-z0-9]{3,}", normalizar_texto(titulo))
        if p not in PALAVRAS_GENERICAS_PRODUTO and not p.isdigit()
    ]


def localizar_link_loja(produto, chave):
    principal, palavras = chaves_da_loja(produto.get("loja", ""))
    if len(principal) < 3:
        raise ErroBusca("Nome da loja indisponível para localizar o anúncio.")
    termos = palavras_do_produto(produto["titulo"])
    try:
        resposta = requests.post(
            URL_SERPER_BUSCA,
            json={
                "q": f"{produto['titulo']} {produto['loja']}",
                "gl": "br",
                "hl": "pt-br",
                "num": 10,
            },
            headers={"X-API-KEY": chave, "Content-Type": "application/json"},
            timeout=TIMEOUT,
        )
    except requests.RequestException as erro:
        raise ErroBusca(
            f"Não foi possível localizar o link da loja ({type(erro).__name__})."
        ) from erro
    if resposta.status_code != 200:
        raise ErroBusca(
            f"Busca do link da loja recusada (HTTP {resposta.status_code})."
        )
    try:
        itens = resposta.json().get("organic", [])
    except ValueError:
        raise ErroBusca("Resposta inválida ao localizar o link da loja.") from None

    escolhido, melhor_pontuacao = None, -1.0
    for item in itens:
        link = item.get("link", "")
        if not re.match(r"^https?://", link):
            continue
        anfitriao_bruto = urlparse(link).netloc.lower().replace("www.", "")
        if any(ignorado in anfitriao_bruto for ignorado in DOMINIOS_IGNORADOS):
            continue
        anfitriao = re.sub(r"[^a-z0-9]", "", anfitriao_bruto)
        texto = normalizar_texto(
            f"{item.get('title', '')} {item.get('snippet', '')} {link}"
        )
        sobreposicao = (
            sum(1 for termo in termos if termo in texto) / len(termos)
            if termos
            else 0.0
        )
        dominio_confere = principal in anfitriao or any(
            p in anfitriao for p in palavras
        )
        nome_no_texto = principal in re.sub(r"[^a-z0-9]", "", texto) or (
            bool(palavras) and all(p in texto for p in palavras)
        )
        if not (dominio_confere or (nome_no_texto and sobreposicao >= 0.5)):
            continue
        pontuacao = sobreposicao + (1.0 if dominio_confere else 0.0)
        if pontuacao > melhor_pontuacao:
            escolhido, melhor_pontuacao = link, pontuacao
    return escolhido


def obter_link_loja(produto, config):
    tipo = produto.get("tipo_link", "busca")
    if tipo == "direto":
        return produto["link"], "direto", ""
    chave = config.get("serper_key", "")
    if not chave:
        return (
            produto["link"],
            tipo,
            "Sem chave do Serper para localizar o link da loja.",
        )
    try:
        link = localizar_link_loja(produto, chave)
    except ErroBusca as erro:
        return produto["link"], tipo, str(erro)
    if link:
        return link, "direto", ""
    return (
        produto["link"],
        tipo,
        "Não encontrei o anúncio nessa loja. Abrindo o Google Shopping.",
    )


def buscar_produtos(termo, config, gerenciador_token, limite=20):
    termo = termo.strip()
    if not termo:
        raise ValueError("Informe o que deseja buscar.")
    falhas = []
    provedores = []
    if gerenciador_token.disponivel():
        provedores.append(
            lambda: buscar_mercado_livre(termo, limite, gerenciador_token)
        )
    if config.get("serper_key"):
        provedores.append(lambda: buscar_serper(termo, limite, config["serper_key"]))
    if config.get("serpapi_key"):
        provedores.append(
            lambda: buscar_google_shopping(termo, limite, config["serpapi_key"])
        )
    provedores.append(lambda: buscar_mercado_livre_html(termo, limite))
    for provedor in provedores:
        try:
            produtos = provedor()
            if produtos:
                return normalizar_links(produtos)
            falhas.append("Nenhum resultado em uma das fontes.")
        except ErroBusca as erro:
            falhas.append(str(erro))
    raise ErroBusca("\n".join(falhas))


_motores = {}
PADRAO_MEDIDA = re.compile(r"^\d+([.,]\d+)?\s?(g|kg|ml|l|mg)$", re.IGNORECASE)


def carregar_motor_ocr():
    if "ocr" in _motores:
        return _motores["ocr"]
    try:
        from rapidocr_onnxruntime import RapidOCR
    except ImportError:
        from rapidocr import RapidOCR
    _motores["ocr"] = RapidOCR()
    return _motores["ocr"]


def extrair_linhas_ocr(imagem):
    import numpy as np

    saida = carregar_motor_ocr()(np.array(imagem.convert("RGB")))
    linhas = []
    if hasattr(saida, "txts"):
        if saida.txts is None:
            return linhas
        for caixa, texto, confianca in zip(saida.boxes, saida.txts, saida.scores):
            linhas.append((caixa, texto, float(confianca)))
    else:
        resultado = saida[0] if isinstance(saida, tuple) else saida
        for caixa, texto, confianca in resultado or []:
            linhas.append((caixa, texto, float(confianca)))
    return linhas


TRADUCOES = {
    "running shoe": "tênis de corrida",
    "sandal": "sandália",
    "loafer": "mocassim",
    "cowboy boot": "bota",
    "clog": "tamanco",
    "sock": "meia",
    "jersey": "camiseta",
    "sweatshirt": "moletom",
    "jean": "calça jeans",
    "cardigan": "casaco",
    "suit": "terno",
    "trench coat": "casaco",
    "miniskirt": "saia",
    "bow tie": "gravata borboleta",
    "backpack": "mochila",
    "purse": "bolsa",
    "wallet": "carteira",
    "umbrella": "guarda-chuva",
    "sunglasses": "óculos de sol",
    "sunglass": "óculos de sol",
    "wristwatch": "relógio de pulso",
    "digital watch": "relógio digital",
    "cellular telephone": "celular",
    "laptop": "notebook",
    "notebook": "notebook",
    "desktop computer": "computador",
    "monitor": "monitor",
    "screen": "monitor",
    "television": "televisão",
    "remote control": "controle remoto",
    "joystick": "controle joystick",
    "mouse": "mouse",
    "computer keyboard": "teclado",
    "headphone": "fone de ouvido",
    "ipod": "ipod",
    "reflex camera": "câmera",
    "polaroid camera": "câmera instantânea",
    "water bottle": "garrafa de água",
    "pop bottle": "garrafa",
    "beer bottle": "garrafa de cerveja",
    "wine bottle": "garrafa de vinho",
    "coffee mug": "caneca",
    "cup": "copo",
    "lipstick": "batom",
    "perfume": "perfume",
    "lotion": "hidratante",
    "sunscreen": "protetor solar",
    "teddy bear": "urso de pelúcia",
    "mountain bike": "bicicleta",
    "electric guitar": "guitarra",
    "acoustic guitar": "violão",
    "digital clock": "relógio digital",
    "hair spray": "spray de cabelo",
}


def preparar_imagem_ocr(imagem, lado_alvo=1280):
    imagem = imagem.convert("RGB")
    maior = max(imagem.size)
    if maior < lado_alvo:
        fator = lado_alvo / maior
        imagem = imagem.resize(
            (int(imagem.width * fator), int(imagem.height * fator)), Image.LANCZOS
        )
    return imagem


def gerar_variantes_ocr(imagem):
    base = preparar_imagem_ocr(imagem, 960)
    realcada = ImageOps.autocontrast(base.convert("L"), cutoff=2).filter(
        ImageFilter.SHARPEN
    )
    return base, realcada.convert("RGB")


def coletar_linhas(variante, encontradas):
    for caixa, texto, confianca in extrair_linhas_ocr(variante):
        texto = texto.strip()
        if confianca < 0.3 or len(texto) < 3 or not any(c.isalpha() for c in texto):
            continue
        if PADRAO_MEDIDA.match(texto):
            continue
        ys = [float(ponto[1]) for ponto in caixa]
        registro = (max(ys) - min(ys), min(ys), texto, confianca)
        anterior = encontradas.get(texto.lower())
        if anterior is None or confianca > anterior[3]:
            encontradas[texto.lower()] = registro


def montar_termo(encontradas, maximo_linhas):
    principais = sorted(encontradas.values(), reverse=True)[:maximo_linhas]
    palavras = []
    for linha in sorted(principais, key=lambda registro: registro[1]):
        for palavra in linha[2].split():
            limpa = re.sub(r"[^\w]", "", palavra)
            if len(limpa) < 2:
                continue
            for item in palavras:
                if (
                    SequenceMatcher(None, limpa.lower(), item[0].lower()).ratio()
                    >= 0.75
                ):
                    if linha[3] > item[1]:
                        item[0], item[1] = limpa, linha[3]
                    break
            else:
                palavras.append([limpa, linha[3]])
    textos = [item[0] for item in palavras]
    return " ".join(
        t
        for t in textos
        if not (
            len(t) >= 8
            and sum(
                1 for o in textos if o != t and len(o) >= 3 and o.lower() in t.lower()
            )
            >= 2
        )
    )


def ler_texto_embalagem(imagem, maximo_linhas=6):
    encontradas = {}
    base, realcada = gerar_variantes_ocr(imagem)
    coletar_linhas(base, encontradas)
    termo = montar_termo(encontradas, maximo_linhas)
    if len(termo.split()) < 3:
        coletar_linhas(realcada, encontradas)
        termo = montar_termo(encontradas, maximo_linhas)
    return termo


def ocr_disponivel():
    try:
        carregar_motor_ocr()
        return True
    except Exception:
        return False


def classificar_imagem(imagem):
    import torch
    from torchvision import models

    if "modelo" not in _motores:
        pesos = models.MobileNet_V3_Large_Weights.DEFAULT
        _motores["modelo"] = models.mobilenet_v3_large(weights=pesos).eval()
        _motores["pesos"] = pesos
    pesos = _motores["pesos"]
    entrada = pesos.transforms()(imagem.convert("RGB")).unsqueeze(0)
    with torch.no_grad():
        probabilidades = _motores["modelo"](entrada).softmax(1)[0]
    indice = int(probabilidades.argmax())
    rotulo = pesos.meta["categories"][indice].split(",")[0].strip()
    return rotulo, float(probabilidades[indice])


def traduzir_rotulo(rotulo):
    return TRADUCOES.get(rotulo.lower(), rotulo)


def codificar_imagem_para_envio(imagem, lado=768):
    copia = imagem.convert("RGB")
    copia.thumbnail((lado, lado))
    buffer = io.BytesIO()
    copia.save(buffer, "JPEG", quality=80)
    return base64.b64encode(buffer.getvalue()).decode("ascii")


def escolher_modelo_gemini(chave, modelo_fixo=""):
    if modelo_fixo:
        return (
            modelo_fixo
            if modelo_fixo.startswith("models/")
            else "models/" + modelo_fixo
        )
    if "gemini_modelo" in _motores:
        return _motores["gemini_modelo"]
    resposta = requests.get(
        f"{URL_GEMINI}/models",
        params={"pageSize": 100},
        headers={"x-goog-api-key": chave},
        timeout=(10, 15),
    )
    resposta.raise_for_status()
    nomes = [
        modelo["name"]
        for modelo in resposta.json().get("models", [])
        if "generateContent" in modelo.get("supportedGenerationMethods", [])
        and "flash" in modelo["name"]
    ]
    if not nomes:
        raise ErroIdentificacao("Gemini: nenhum modelo disponível para esta chave.")
    evitar = (
        "image",
        "tts",
        "live",
        "audio",
        "exp",
        "preview",
        "thinking",
        "latest",
        "robotics",
        "computer",
    )
    limpos = [nome for nome in nomes if not any(termo in nome for termo in evitar)]
    leves = sorted([nome for nome in limpos if "lite" in nome], reverse=True)
    comuns = sorted([nome for nome in limpos if "lite" not in nome], reverse=True)
    escolhido = (leves or comuns or sorted(nomes, reverse=True))[0]
    _motores["gemini_modelo"] = escolhido
    print("[Gemini] modelo escolhido:", escolhido)
    return escolhido


def identificar_com_gemini(imagem, chave, modelo_fixo=""):
    instrucao = (
        "Identifique o produto principal da imagem para pesquisar em uma loja online no Brasil. "
        "Leia o texto visível na embalagem ou no produto (marca, nome, sabor, volume, modelo) e use-o. "
        "Dê até 3 hipóteses, da mais provável para a menos provável, uma por linha, cada uma com "
        "marca, nome e modelo em no máximo 8 palavras, sem numeração e sem explicações. "
        "Cite a marca somente se ela estiver visível no produto ou se você tiver certeza; caso "
        "contrário, descreva o produto de forma genérica (por exemplo: chinelo slide branco de "
        "espuma) em vez de inventar uma marca. Se não houver produto identificável, responda NADA."
    )
    inicio = time.time()
    try:
        modelo = escolher_modelo_gemini(chave, modelo_fixo)
        resposta = requests.post(
            f"{URL_GEMINI}/{modelo}:generateContent",
            headers={"x-goog-api-key": chave, "Content-Type": "application/json"},
            json={
                "contents": [
                    {
                        "parts": [
                            {"text": instrucao},
                            {
                                "inline_data": {
                                    "mime_type": "image/jpeg",
                                    "data": codificar_imagem_para_envio(imagem),
                                }
                            },
                        ]
                    }
                ],
                "generationConfig": {"temperature": 0, "maxOutputTokens": 2048},
            },
            timeout=(10, 25),
        )
    except requests.ConnectionError:
        raise ErroIdentificacao("Gemini: sem conexão com a internet.") from None
    except requests.Timeout:
        raise ErroIdentificacao("Gemini: tempo de resposta esgotado.") from None
    except requests.HTTPError as erro:
        codigo = erro.response.status_code if erro.response is not None else "?"
        raise ErroIdentificacao(
            f"Gemini: chave recusada ou indisponível (HTTP {codigo})."
        ) from erro
    except requests.RequestException as erro:
        raise ErroIdentificacao(f"Gemini: erro de rede ({erro}).") from erro
    print(
        f"[Gemini] resposta em {time.time() - inicio:.1f}s (HTTP {resposta.status_code})"
    )
    if resposta.status_code in (401, 403):
        raise ErroIdentificacao(
            "Gemini: chave inválida. Confira o valor de gemini_key."
        )
    if resposta.status_code == 404:
        _motores.pop("gemini_modelo", None)
        if modelo_fixo:
            print(
                f"[Gemini] modelo '{modelo_fixo}' indisponível; usando escolha automática."
            )
            return identificar_com_gemini(imagem, chave, "")
        raise ErroIdentificacao(f"Gemini: modelo {modelo} indisponível (HTTP 404).")
    if resposta.status_code == 429:
        raise ErroIdentificacao(
            "Gemini: limite gratuito de uso atingido. Tente mais tarde."
        )
    if resposta.status_code != 200:
        raise ErroIdentificacao(
            f"Gemini: resposta inesperada (HTTP {resposta.status_code})."
        )
    try:
        partes = resposta.json()["candidates"][0]["content"]["parts"]
        texto = "\n".join(
            parte["text"]
            for parte in partes
            if isinstance(parte, dict) and parte.get("text")
        )
    except (KeyError, IndexError, TypeError, ValueError):
        print("[Gemini] resposta sem texto:", resposta.text[:300])
        return []
    hipoteses = []
    for linha in texto.splitlines():
        linha = re.sub(r"^\s*(?:[-*\u2022]|\d+[.)])\s*", "", linha).strip(" \"'*.")
        if not linha or linha.upper().startswith("NADA") or linha in hipoteses:
            continue
        hipoteses.append(linha[:80])
    return hipoteses[:3]


def identificar_localmente(imagem):
    texto = ""
    try:
        texto = ler_texto_embalagem(imagem)
    except ImportError:
        pass
    if len(texto.split()) >= 2:
        return texto
    try:
        rotulo, confianca = classificar_imagem(imagem)
    except ImportError:
        if texto:
            return texto
        raise ErroIdentificacao(
            "Nenhum reconhecedor instalado. Rode: python -m pip install rapidocr-onnxruntime"
        ) from None
    except Exception:
        return texto
    if confianca < 0.4:
        return texto
    return f"{texto} {traduzir_rotulo(rotulo)}".strip()


def identificar_objeto(imagem, config=None):
    config = config or {}
    chave = config.get("gemini_key", "")
    aviso = ""
    if chave:
        try:
            hipoteses = identificar_com_gemini(
                imagem, chave, config.get("gemini_modelo", "")
            )
            if hipoteses:
                return hipoteses[0], "", hipoteses[1:]
            aviso = "Gemini não reconheceu um produto na imagem."
        except ErroIdentificacao as erro:
            aviso = str(erro)
            print("[Identificação]", aviso)
    resultado = identificar_localmente(imagem)
    if not resultado and aviso:
        raise ErroIdentificacao(aviso)
    return resultado, aviso, []


BLOCOS_TENDENCIA = "▁▂▃▄▅▆▇█"
UNIDADES_BASE = {
    "kg": ("g", 1000),
    "g": ("g", 1),
    "mg": ("g", 0.001),
    "l": ("ml", 1000),
    "ml": ("ml", 1),
}
PADRAO_QUANTIDADE = re.compile(
    r"(\d+(?:\.\d+)?)\s*(kg|mg|ml|g|l|unidades?|unid|und|un)\b"
)
PADRAO_MULTIPLO = re.compile(
    r"\bkit\b|\bc/\s*\d|\b\d+\s*x\b|\bx\s*\d|\bcom\s+\d+\b|\bcaixas?\b"
)


def extrair_quantidade(titulo):
    texto = titulo.lower().replace(",", ".")
    if PADRAO_MULTIPLO.search(texto):
        return None
    achados = PADRAO_QUANTIDADE.findall(texto)
    if len(achados) != 1:
        return None
    valor, unidade = float(achados[0][0]), achados[0][1]
    if valor <= 0:
        return None
    if unidade.startswith("un"):
        return valor, "un"
    base, fator = UNIDADES_BASE[unidade]
    return valor * fator, base


def calcular_custo_unitario(preco, quantidade, base):
    if base == "un":
        return preco / quantidade, f"{formatar_preco(preco / quantidade)} /un"
    custo = preco / (quantidade / 100)
    return custo, f"{formatar_preco(custo)} /100 {base}"


ORDEM_SELOS = [
    "★ Melhor preço",
    "Bom preço",
    "Preço médio",
    "Caro",
    "Muito caro",
    "⚠ Verificar",
]
TAGS_SELO = {
    "★ Melhor preço": "melhor",
    "Bom preço": "bom",
    "Preço médio": "medio",
    "Caro": "caro",
    "Muito caro": "muitocaro",
    "⚠ Verificar": "suspeito",
}
CORES_SELO = {
    "melhor": "#22c55e",
    "bom": "#86efac",
    "medio": COR_TEXTO,
    "caro": "#fbbf24",
    "muitocaro": "#fb923c",
    "suspeito": "#f87171",
}
LEGENDA_SELOS = [
    ("Melhor preço", "melhor"),
    ("Bom preço", "bom"),
    ("Preço médio", "medio"),
    ("Caro", "caro"),
    ("Muito caro", "muitocaro"),
    ("Verificar", "suspeito"),
]


def classificar_oferta(produto, melhor, mediana):
    if produto["suspeito"]:
        return "⚠ Verificar"
    if produto is melhor:
        return "★ Melhor preço"
    razao = produto["preco"] / mediana if mediana else 1
    if razao <= 0.9:
        return "Bom preço"
    if razao <= 1.15:
        return "Preço médio"
    if razao <= 1.6:
        return "Caro"
    return "Muito caro"


def texto_diferenca(preco, mediana):
    if not mediana:
        return "-"
    return f"{(preco / mediana - 1) * 100:+.0f}%"


def analisar_precos(produtos):
    if not produtos:
        return [], {}
    for produto in produtos:
        produto["custo_unit"], produto["custo_texto"], produto["custo_base"] = (
            None,
            "",
            "",
        )
        quantidade = extrair_quantidade(produto["titulo"])
        if quantidade:
            custo, texto = calcular_custo_unitario(
                produto["preco"], quantidade[0], quantidade[1]
            )
            produto["custo_unit"], produto["custo_texto"], produto["custo_base"] = (
                custo,
                texto,
                quantidade[1],
            )

    grupos = {}
    for produto in produtos:
        if produto["custo_unit"] is not None:
            grupos.setdefault(produto["custo_base"], []).append(produto)
    dominante = max(grupos.values(), key=len) if grupos else []
    if len(dominante) < 3:
        dominante = []
    mediana_custo = (
        statistics.median(p["custo_unit"] for p in dominante) if dominante else None
    )

    mediana_geral = statistics.median(produto["preco"] for produto in produtos)
    for produto in produtos:
        if mediana_custo is not None and produto in dominante:
            produto["suspeito"] = produto["custo_unit"] < 0.4 * mediana_custo
        else:
            produto["suspeito"] = (
                len(produtos) >= 5 and produto["preco"] < 0.4 * mediana_geral
            )

    confiaveis = [
        produto for produto in produtos if not produto["suspeito"]
    ] or produtos
    mediana = statistics.median(produto["preco"] for produto in confiaveis)
    melhor = min(confiaveis, key=lambda produto: produto["preco"])
    for produto in produtos:
        produto["selo"] = classificar_oferta(produto, melhor, mediana)
        produto["vs_texto"] = texto_diferenca(produto["preco"], mediana)

    candidatos = [produto for produto in dominante if not produto["suspeito"]]
    if candidatos:
        melhor_custo = min(candidatos, key=lambda produto: produto["custo_unit"])
        melhor_custo["custo_texto"] = "★ " + melhor_custo["custo_texto"]

    produtos.sort(key=lambda produto: (produto["suspeito"], produto["preco"]))
    resumo = {
        "total": len(produtos),
        "menor_preco": melhor["preco"],
        "menor_loja": melhor["loja"],
        "mediana": mediana,
        "maior_preco": max(produto["preco"] for produto in produtos),
        "suspeitas": sum(1 for produto in produtos if produto["suspeito"]),
    }
    return produtos, resumo


def resolver_melhores_links(produtos, config, quantidade=5):
    chave = config.get("serper_key", "")
    if not chave:
        return
    candidatos = [
        produto
        for produto in sorted(produtos, key=lambda p: p["preco"])
        if not produto["suspeito"] and produto.get("tipo_link") != "direto"
    ][:quantidade]

    def tarefa(produto):
        try:
            link = localizar_link_loja(produto, chave)
        except ErroBusca:
            return
        if link:
            produto["link"], produto["tipo_link"] = link, "direto"

    if candidatos:
        with ThreadPoolExecutor(max_workers=len(candidatos)) as executor:
            list(executor.map(tarefa, candidatos))


def buscar_e_analisar(termo, config, gerenciador_token):
    produtos, resumo = analisar_precos(
        buscar_produtos(termo, config, gerenciador_token)
    )
    resolver_melhores_links(produtos, config)
    return produtos, resumo


def texto_radar(resumo):
    if not resumo:
        return "Radar Jovi: faça uma busca para analisar os preços."
    texto = (
        f"Radar Jovi  •  {resumo['total']} ofertas  •  melhor preço "
        f"{formatar_preco(resumo['menor_preco'])} ({resumo['menor_loja']})  •  "
        f"mediana {formatar_preco(resumo['mediana'])}  •  maior {formatar_preco(resumo['maior_preco'])}"
    )
    if resumo["suspeitas"]:
        texto += f"  •  {resumo['suspeitas']} oferta(s) para verificar"
    return texto


def gerar_tendencia(historico, preco_atual):
    todos = [registro["preco"] for registro in historico]
    if len(todos) < 2:
        return "sem histórico ainda"
    recentes = todos[-8:]
    minimo, maximo = min(recentes), max(recentes)
    if maximo == minimo:
        grafico = BLOCOS_TENDENCIA[3] * len(recentes)
    else:
        grafico = "".join(
            BLOCOS_TENDENCIA[round((valor - minimo) / (maximo - minimo) * 7)]
            for valor in recentes
        )
    if max(todos) == min(todos):
        nota = "estável"
    elif preco_atual <= min(todos):
        nota = "mínimo histórico"
    elif preco_atual > sum(todos) / len(todos) * 1.05:
        nota = "acima da média"
    else:
        nota = "na média"
    return f"{grafico} {nota}"


def criar_favorito(produto):
    return {
        "id": produto["id"],
        "titulo": produto["titulo"],
        "loja": produto["loja"],
        "link": produto["link"],
        "preco_inicial": produto["preco"],
        "preco_atual": produto["preco"],
        "preco_alvo": None,
        "historico": [{"data": agora_texto(), "preco": produto["preco"]}],
    }


def avaliar_alerta(favorito, novo_preco):
    anterior = favorito["preco_atual"]
    alvo = favorito.get("preco_alvo")
    if alvo and novo_preco <= alvo and anterior > alvo:
        return f"{favorito['titulo']}: atingiu o preço alvo ({formatar_preco(novo_preco)})."
    if anterior > 0:
        queda = (anterior - novo_preco) / anterior * 100
        if queda >= QUEDA_MINIMA_PERCENTUAL:
            return (
                f"{favorito['titulo']}: queda de {queda:.1f}% "
                f"({formatar_preco(anterior)} → {formatar_preco(novo_preco)})."
            )
    return None


def atualizar_favorito(favorito, config, gerenciador_token):
    produtos = buscar_produtos(favorito["titulo"], config, gerenciador_token, limite=30)
    for produto in produtos:
        if produto["id"].replace("-", "") == favorito["id"].replace("-", ""):
            return produto["preco"]
    raise ErroBusca("Produto não encontrado na busca atual.")


def atualizar_todos_favoritos(dados, config, gerenciador_token):
    novos_alertas = []
    erros = []
    for favorito in list(dados["favoritos"]):
        try:
            novo_preco = atualizar_favorito(favorito, config, gerenciador_token)
        except (ErroBusca, ValueError) as erro:
            erros.append(f"{favorito['titulo']}: {erro}")
            continue
        mensagem = avaliar_alerta(favorito, novo_preco)
        if novo_preco != favorito["preco_atual"]:
            favorito["historico"].append({"data": agora_texto(), "preco": novo_preco})
        favorito["preco_atual"] = novo_preco
        if mensagem:
            novos_alertas.append({"data": agora_texto(), "mensagem": mensagem})
    dados["alertas"] = (novos_alertas + dados["alertas"])[:LIMITE_ALERTAS]
    return novos_alertas, erros


PORTA_CELULAR = 8765

ARQUIVO_PAGINA_CELULAR = os.path.join(PASTA_BASE, "recursos", "pagina_celular.html")


def carregar_pagina_celular():
    try:
        with open(ARQUIVO_PAGINA_CELULAR, "r", encoding="utf-8") as arquivo:
            return arquivo.read()
    except OSError:
        return "<h1>Página do modo celular não encontrada.</h1>"


def descobrir_ip_local():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as soquete:
            soquete.connect(("10.255.255.255", 1))
            return soquete.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def validar_produto(dado):
    try:
        produto = {
            "id": str(dado["id"])[:100],
            "titulo": str(dado["titulo"])[:300],
            "preco": float(dado["preco"]),
            "loja": str(dado.get("loja", ""))[:100],
            "link": str(dado.get("link", ""))[:1000],
        }
    except (KeyError, TypeError, ValueError, AttributeError):
        raise ValueError("Produto inválido.") from None
    if produto["preco"] <= 0:
        raise ValueError("Produto inválido.")
    return produto


def resumo_favorito(fav):
    inicial = fav.get("preco_inicial") or 0
    atual = fav.get("preco_atual") or 0
    link, tipo = classificar_link(fav.get("link"), fav["titulo"], fav.get("loja", ""))
    return {
        "id": fav["id"],
        "titulo": fav["titulo"],
        "loja": fav.get("loja", ""),
        "link": link,
        "tipo_link": tipo,
        "preco_inicial": inicial,
        "preco_atual": atual,
        "preco_alvo": fav.get("preco_alvo"),
        "variacao": (atual - inicial) / inicial * 100 if inicial else 0.0,
        "tendencia": gerar_tendencia(fav.get("historico", []), atual),
    }


QR_VERSOES = {
    1: (19, 7, 1),
    2: (34, 10, 1),
    3: (55, 15, 1),
    4: (80, 20, 1),
    5: (108, 26, 1),
    6: (136, 18, 2),
}
QR_ALINHAMENTO = {1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34]}


def qr_multiplicar(x, y):
    resultado = 0
    for i in range(7, -1, -1):
        resultado = (resultado << 1) ^ ((resultado >> 7) * 0x11D)
        resultado ^= ((y >> i) & 1) * x
    return resultado


def qr_divisor(grau):
    resultado = [0] * (grau - 1) + [1]
    raiz = 1
    for _ in range(grau):
        for j in range(grau):
            resultado[j] = qr_multiplicar(resultado[j], raiz)
            if j + 1 < grau:
                resultado[j] ^= resultado[j + 1]
        raiz = qr_multiplicar(raiz, 2)
    return resultado


def qr_resto(dados, divisor):
    resultado = [0] * len(divisor)
    for byte in dados:
        fator = byte ^ resultado.pop(0)
        resultado.append(0)
        for i, coeficiente in enumerate(divisor):
            resultado[i] ^= qr_multiplicar(coeficiente, fator)
    return resultado


def qr_codificar_dados(texto):
    dados = texto.encode("utf-8")
    for versao, (capacidade, _, _) in QR_VERSOES.items():
        if len(dados) <= capacidade - 2:
            break
    else:
        raise ValueError("Texto longo demais para o QR Code.")
    capacidade, tamanho_ec, blocos = QR_VERSOES[versao]
    bits = "0100" + format(len(dados), "08b") + "".join(format(b, "08b") for b in dados)
    bits += "0" * min(4, capacidade * 8 - len(bits))
    bits += "0" * (-len(bits) % 8)
    palavras = [int(bits[i : i + 8], 2) for i in range(0, len(bits), 8)]
    enchimento = [0xEC, 0x11]
    while len(palavras) < capacidade:
        palavras.append(enchimento[(len(palavras) - len(bits) // 8) % 2])
    tamanho_bloco = capacidade // blocos
    divisor = qr_divisor(tamanho_ec)
    lista_dados = [
        palavras[i * tamanho_bloco : (i + 1) * tamanho_bloco] for i in range(blocos)
    ]
    lista_ec = [qr_resto(bloco, divisor) for bloco in lista_dados]
    saida = []
    for i in range(tamanho_bloco):
        saida.extend(bloco[i] for bloco in lista_dados)
    for i in range(tamanho_ec):
        saida.extend(bloco[i] for bloco in lista_ec)
    return versao, saida


def qr_penalidade(matriz):
    tamanho = len(matriz)
    pontos = 0
    linhas = ["".join("1" if c else "0" for c in linha) for linha in matriz]
    colunas = ["".join(linhas[y][x] for y in range(tamanho)) for x in range(tamanho)]
    for sequencia in linhas + colunas:
        for correspondencia in re.finditer(r"0{5,}|1{5,}", sequencia):
            pontos += 3 + len(correspondencia.group()) - 5
        for padrao in ("10111010000", "00001011101"):
            inicio = sequencia.find(padrao)
            while inicio != -1:
                pontos += 40
                inicio = sequencia.find(padrao, inicio + 1)
    for y in range(tamanho - 1):
        for x in range(tamanho - 1):
            if (
                matriz[y][x]
                == matriz[y][x + 1]
                == matriz[y + 1][x]
                == matriz[y + 1][x + 1]
            ):
                pontos += 3
    escuros = sum(linha.count("1") for linha in linhas)
    pontos += (abs(escuros * 20 - tamanho * tamanho * 10) // (tamanho * tamanho)) * 10
    return pontos


def qr_mascara(mascara, x, y):
    return [
        (x + y) % 2 == 0,
        y % 2 == 0,
        x % 3 == 0,
        (x + y) % 3 == 0,
        (x // 3 + y // 2) % 2 == 0,
        x * y % 2 + x * y % 3 == 0,
        (x * y % 2 + x * y % 3) % 2 == 0,
        ((x + y) % 2 + x * y % 3) % 2 == 0,
    ][mascara]


def gerar_matriz_qr(texto):
    versao, palavras = qr_codificar_dados(texto)
    tamanho = 17 + 4 * versao
    modulos = [[False] * tamanho for _ in range(tamanho)]
    funcao = [[False] * tamanho for _ in range(tamanho)]

    def definir(x, y, escuro):
        modulos[y][x] = escuro
        funcao[y][x] = True

    def desenhar_formato(mascara):
        dados = (1 << 3) | mascara
        resto = dados
        for _ in range(10):
            resto = (resto << 1) ^ ((resto >> 9) * 0x537)
        bits = ((dados << 10) | resto) ^ 0x5412

        def bit(i):
            return (bits >> i) & 1 == 1

        for i in range(0, 6):
            definir(8, i, bit(i))
        definir(8, 7, bit(6))
        definir(8, 8, bit(7))
        definir(7, 8, bit(8))
        for i in range(9, 15):
            definir(14 - i, 8, bit(i))
        for i in range(0, 8):
            definir(tamanho - 1 - i, 8, bit(i))
        for i in range(8, 15):
            definir(8, tamanho - 15 + i, bit(i))
        definir(8, tamanho - 8, True)

    for i in range(tamanho):
        definir(6, i, i % 2 == 0)
        definir(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (tamanho - 4, 3), (3, tamanho - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                x, y = cx + dx, cy + dy
                if 0 <= x < tamanho and 0 <= y < tamanho:
                    definir(x, y, max(abs(dx), abs(dy)) not in (2, 4))
    posicoes = QR_ALINHAMENTO[versao]
    for i, px in enumerate(posicoes):
        for j, py in enumerate(posicoes):
            if (
                (i == 0 and j == 0)
                or (i == 0 and j == len(posicoes) - 1)
                or (i == len(posicoes) - 1 and j == 0)
            ):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    definir(px + dx, py + dy, max(abs(dx), abs(dy)) != 1)
    desenhar_formato(0)

    indice = 0
    total_bits = len(palavras) * 8
    direita = tamanho - 1
    while direita >= 1:
        if direita == 6:
            direita = 5
        for vertical in range(tamanho):
            for j in range(2):
                x = direita - j
                subindo = ((direita + 1) & 2) == 0
                y = tamanho - 1 - vertical if subindo else vertical
                if not funcao[y][x] and indice < total_bits:
                    modulos[y][x] = (
                        palavras[indice >> 3] >> (7 - (indice & 7))
                    ) & 1 == 1
                    indice += 1
        direita -= 2

    def aplicar(mascara):
        for y in range(tamanho):
            for x in range(tamanho):
                if not funcao[y][x] and qr_mascara(mascara, x, y):
                    modulos[y][x] = not modulos[y][x]

    melhor, menor_penalidade = 0, None
    for mascara in range(8):
        aplicar(mascara)
        desenhar_formato(mascara)
        penalidade = qr_penalidade(modulos)
        if menor_penalidade is None or penalidade < menor_penalidade:
            melhor, menor_penalidade = mascara, penalidade
        aplicar(mascara)
    aplicar(melhor)
    desenhar_formato(melhor)
    return modulos


def gerar_qrcode(texto, tamanho=300):
    try:
        matriz = gerar_matriz_qr(texto)
    except ValueError:
        return None
    borda = 4
    escala = max(4, tamanho // (len(matriz) + 2 * borda))
    lado = (len(matriz) + 2 * borda) * escala
    imagem = Image.new("RGB", (lado, lado), "white")
    desenho = ImageDraw.Draw(imagem)
    for y, linha in enumerate(matriz):
        for x, escuro in enumerate(linha):
            if escuro:
                x0, y0 = (x + borda) * escala, (y + borda) * escala
                desenho.rectangle(
                    [x0, y0, x0 + escala - 1, y0 + escala - 1], fill="black"
                )
    return imagem


class ServidorCelular:
    def __init__(self, app, porta=PORTA_CELULAR):
        self.app = app
        self.porta = porta
        self.token = secrets.token_urlsafe(6)
        self.httpd = None

    def url(self):
        return f"http://{descobrir_ip_local()}:{self.porta}/?t={self.token}"

    def iniciar(self):
        servidor = self

        class Manipulador(BaseHTTPRequestHandler):
            def log_message(self, formato, *argumentos):
                pass

            def responder(self, codigo, corpo, tipo="application/json; charset=utf-8"):
                dados = (
                    corpo
                    if isinstance(corpo, bytes)
                    else json.dumps(corpo, ensure_ascii=False).encode("utf-8")
                )
                self.send_response(codigo)
                self.send_header("Content-Type", tipo)
                self.send_header("Content-Length", str(len(dados)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(dados)

            def autorizado(self):
                consulta = parse_qs(urlparse(self.path).query)
                token = self.headers.get("X-Token") or (consulta.get("t") or [""])[0]
                return secrets.compare_digest(
                    token.encode("utf-8"), servidor.token.encode("utf-8")
                )

            def ler_corpo(self, limite=8 * 1024 * 1024):
                try:
                    tamanho = int(self.headers.get("Content-Length", 0))
                except ValueError:
                    raise ValueError("Requisição inválida.") from None
                if tamanho <= 0 or tamanho > limite:
                    raise ValueError("Tamanho de dados inválido.")
                return self.rfile.read(tamanho)

            def ler_json(self, limite=65536):
                try:
                    dado = json.loads(self.ler_corpo(limite).decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    raise ValueError("Requisição inválida.") from None
                if not isinstance(dado, dict):
                    raise ValueError("Requisição inválida.")
                return dado

            def sincronizar_desktop(self):
                app = servidor.app
                app.fila.put(
                    (
                        lambda sucesso, _: (
                            app.atualizar_tabela_favoritos(),
                            app.atualizar_lista_alertas(),
                        ),
                        (True, None),
                    )
                )

            def tratar(self, acao):
                try:
                    if not self.autorizado():
                        return self.responder(
                            403,
                            {
                                "erro": "Acesso negado. Abra o link exibido no computador."
                            },
                        )
                    acao()
                except (ErroBusca, ErroIdentificacao) as erro:
                    self.responder(502, {"erro": str(erro)})
                except ValueError as erro:
                    self.responder(400, {"erro": str(erro)})
                except Exception:
                    self.responder(500, {"erro": "Erro interno no servidor."})

            def do_GET(self):
                self.tratar(self.processar_get)

            def do_POST(self):
                self.tratar(self.processar_post)

            def processar_get(self):
                endereco = urlparse(self.path)
                app = servidor.app
                if endereco.path == "/":
                    return self.responder(
                        200,
                        carregar_pagina_celular().encode("utf-8"),
                        "text/html; charset=utf-8",
                    )
                if endereco.path == "/api/buscar":
                    termo = (parse_qs(endereco.query).get("q") or [""])[0]
                    produtos, resumo = buscar_e_analisar(termo, app.config, app.token)
                    return self.responder(200, {"produtos": produtos, "resumo": resumo})
                if endereco.path == "/api/favoritos":
                    favoritos = [
                        resumo_favorito(fav) for fav in list(app.dados["favoritos"])
                    ]
                    return self.responder(200, {"favoritos": favoritos})
                if endereco.path == "/api/alertas":
                    return self.responder(200, {"alertas": list(app.dados["alertas"])})
                self.responder(404, {"erro": "Rota não encontrada."})

            def processar_post(self):
                caminho = urlparse(self.path).path
                app = servidor.app
                if caminho == "/api/identificar":
                    corpo = self.ler_corpo()
                    try:
                        with Image.open(io.BytesIO(corpo)) as arquivo:
                            imagem = arquivo.convert("RGB")
                    except (OSError, ValueError):
                        raise ValueError("Imagem inválida.") from None
                    texto, aviso, alternativas = identificar_objeto(imagem, app.config)
                    return self.responder(
                        200,
                        {"termo": texto, "alternativas": alternativas, "aviso": aviso},
                    )
                if caminho == "/api/link":
                    produto = validar_produto(self.ler_json())
                    produto["link"], produto["tipo_link"] = classificar_link(
                        produto["link"], produto["titulo"], produto["loja"]
                    )
                    link, tipo, aviso = obter_link_loja(produto, app.config)
                    return self.responder(
                        200, {"link": link, "tipo": tipo, "aviso": aviso}
                    )
                if caminho in ("/api/remover", "/api/alvo", "/api/link_favorito"):
                    dado = self.ler_json()
                    favorito = next(
                        (
                            f
                            for f in app.dados["favoritos"]
                            if f["id"] == str(dado.get("id", ""))
                        ),
                        None,
                    )
                    if favorito is None:
                        raise ValueError("Favorito não encontrado.")
                    if caminho == "/api/remover":
                        app.dados["favoritos"].remove(favorito)
                    elif caminho == "/api/alvo":
                        alvo = dado.get("alvo")
                        if alvo in (None, ""):
                            favorito["preco_alvo"] = None
                        else:
                            try:
                                alvo = float(alvo)
                            except (TypeError, ValueError):
                                raise ValueError("Preço alvo inválido.") from None
                            if not 0 < alvo <= 1000000:
                                raise ValueError("Preço alvo inválido.")
                            favorito["preco_alvo"] = alvo
                    else:
                        favorito["link"], favorito["tipo_link"] = classificar_link(
                            favorito.get("link"),
                            favorito["titulo"],
                            favorito.get("loja", ""),
                        )
                        link, tipo, aviso = obter_link_loja(favorito, app.config)
                        favorito["link"], favorito["tipo_link"] = link, tipo
                        salvar_dados(app.dados)
                        return self.responder(
                            200, {"link": link, "tipo": tipo, "aviso": aviso}
                        )
                    salvar_dados(app.dados)
                    self.sincronizar_desktop()
                    return self.responder(200, {"ok": True})
                if caminho == "/api/atualizar":
                    novos, erros = atualizar_todos_favoritos(
                        app.dados, app.config, app.token
                    )
                    salvar_dados(app.dados)
                    self.sincronizar_desktop()
                    return self.responder(200, {"alertas": novos, "erros": len(erros)})
                if caminho == "/api/limpar_alertas":
                    app.dados["alertas"] = []
                    salvar_dados(app.dados)
                    self.sincronizar_desktop()
                    return self.responder(200, {"ok": True})
                if caminho == "/api/favoritar":
                    produto = validar_produto(self.ler_json())
                    if not any(
                        fav["id"] == produto["id"] for fav in app.dados["favoritos"]
                    ):
                        app.dados["favoritos"].append(criar_favorito(produto))
                        salvar_dados(app.dados)
                        self.sincronizar_desktop()
                    return self.responder(200, {"ok": True})
                self.responder(404, {"erro": "Rota não encontrada."})

        self.httpd = ThreadingHTTPServer(("0.0.0.0", self.porta), Manipulador)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def parar(self):
        if self.httpd is not None:
            self.httpd.shutdown()
            self.httpd.server_close()
            self.httpd = None


LARGURA_APP = 430
LARGURA_VISOR = LARGURA_APP - 32
ALTURA_VISOR = 290
FONTE = "Segoe UI"
FONTE_EMOJI = "Segoe UI Emoji"
COR_CARTAO = COR_PAINEL
COR_ELEVADO = "#1d2540"
COR_NAV = "#0e1424"
COR_SUCESSO = "#22c55e"
COR_PERIGO = "#f87171"
COR_OURO = "#facc15"

TITULOS_PAGINAS = {
    "menu": "Jovi Lens",
    "buscar": "Escanear produto",
    "resultados": "Resultados",
    "favoritos": "Meus favoritos",
    "alertas": "Alertas de promoção",
}
FILTROS_RESULTADOS = [
    ("Todas", None),
    ("Melhores", ("★ Melhor preço", "Bom preço")),
    ("Médias", ("Preço médio",)),
    ("Caras", ("Caro", "Muito caro")),
]
ROTULOS_LINK_LONGOS = {
    "direto": ("✔ Anúncio direto na loja", COR_SUCESSO),
    "google": ("Página do produto no Google Shopping", COR_SUAVE),
    "busca": ("Sem link direto: vamos localizar a loja ao abrir", COR_SUAVE),
}
ICONES_MENU = {"1": "📷", "2": "🔎", "3": "★", "4": "🔔", "5": "🕘", "6": "📱"}


def clarear_cor(cor, fator=0.14):
    try:
        canais = [int(cor[i : i + 2], 16) for i in (1, 3, 5)]
    except ValueError:
        return cor
    return "#%02x%02x%02x" % tuple(int(c + (255 - c) * fator) for c in canais)


def retangulo_arredondado(canvas, x1, y1, x2, y2, raio, **opcoes):
    raio = max(0, min(raio, (x2 - x1) / 2, (y2 - y1) / 2))
    pontos = [
        x1 + raio,
        y1,
        x2 - raio,
        y1,
        x2,
        y1,
        x2,
        y1 + raio,
        x2,
        y2 - raio,
        x2,
        y2,
        x2 - raio,
        y2,
        x1 + raio,
        y2,
        x1,
        y2,
        x1,
        y2 - raio,
        x1,
        y1 + raio,
        x1,
        y1,
    ]
    return canvas.create_polygon(pontos, smooth=True, **opcoes)


def tornar_clicavel(widget, comando):
    widget.bind("<Button-1>", lambda _: comando())
    try:
        widget.configure(cursor="hand2")
    except tk.TclError:
        pass
    for filho in widget.winfo_children():
        tornar_clicavel(filho, comando)


class BotaoModerno(tk.Canvas):
    def __init__(
        self,
        pai,
        texto,
        comando,
        cor=COR_ELEVADO,
        cor_texto="white",
        cor_hover=None,
        largura=120,
        altura=42,
        raio=14,
        fonte=(FONTE, 10, "bold"),
    ):
        super().__init__(
            pai,
            width=largura,
            height=altura,
            bg=pai.cget("bg"),
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.texto, self.comando = texto, comando
        self.cor, self.cor_texto, self.raio, self.fonte = cor, cor_texto, raio, fonte
        self.cor_hover = cor_hover or clarear_cor(cor)
        self.atual = cor
        self.bind("<Configure>", lambda _: self.desenhar())
        self.bind("<Enter>", lambda _: self.mudar(self.cor_hover))
        self.bind("<Leave>", lambda _: self.mudar(self.cor))
        self.bind("<ButtonRelease-1>", self.clicar)

    def desenhar(self):
        self.delete("all")
        largura, altura = self.winfo_width(), self.winfo_height()
        if largura < 4:
            largura, altura = int(self.cget("width")), int(self.cget("height"))
        retangulo_arredondado(
            self,
            1,
            1,
            largura - 1,
            altura - 1,
            self.raio,
            fill=self.atual,
            outline=self.atual,
        )
        self.create_text(
            largura / 2,
            altura / 2,
            text=self.texto,
            fill=self.cor_texto,
            font=self.fonte,
        )

    def mudar(self, cor):
        self.atual = cor
        self.desenhar()

    def configurar_texto(self, texto):
        self.texto = texto
        self.desenhar()

    def definir_cores(self, cor, cor_texto=None, cor_hover=None):
        self.cor, self.atual = cor, cor
        self.cor_hover = cor_hover or clarear_cor(cor)
        if cor_texto:
            self.cor_texto = cor_texto
        self.desenhar()

    def clicar(self, evento):
        if 0 <= evento.x <= self.winfo_width() and 0 <= evento.y <= self.winfo_height():
            self.comando()


class Chip(BotaoModerno):
    def __init__(self, pai, texto, comando, ativo=False):
        fonte = (FONTE, 9, "bold")
        largura = tkfont.Font(family=FONTE, size=9, weight="bold").measure(texto) + 30
        super().__init__(
            pai,
            texto,
            comando,
            cor=COR_DESTAQUE if ativo else COR_ELEVADO,
            cor_texto="white" if ativo else COR_SUAVE,
            largura=largura,
            altura=32,
            raio=16,
            fonte=fonte,
        )

    def definir_ativo(self, ativo):
        self.definir_cores(
            COR_DESTAQUE if ativo else COR_ELEVADO, "white" if ativo else COR_SUAVE
        )


class Cartao(tk.Canvas):
    def __init__(self, pai, cor=COR_CARTAO, raio=18, margem=14):
        super().__init__(
            pai, bg=pai.cget("bg"), highlightthickness=0, bd=0, height=2 * margem + 12
        )
        self.cor, self.raio, self.margem = cor, raio, margem
        self.interno = tk.Frame(self, bg=cor)
        self.janela = self.create_window(
            margem, margem, window=self.interno, anchor="nw"
        )
        self.bind("<Configure>", self.redesenhar)
        self.interno.bind("<Configure>", self.ajustar_altura)
        self.after_idle(self.ajustar_altura)

    def ajustar_altura(self, _=None):
        altura = self.interno.winfo_reqheight() + 2 * self.margem
        if int(float(self.cget("height"))) != altura:
            self.configure(height=altura)

    def redesenhar(self, evento):
        self.delete("fundo")
        retangulo_arredondado(
            self,
            1,
            1,
            evento.width - 1,
            evento.height - 1,
            self.raio,
            fill=self.cor,
            outline=self.cor,
            tags="fundo",
        )
        self.tag_lower("fundo")
        self.itemconfigure(self.janela, width=max(10, evento.width - 2 * self.margem))


class AreaRolavel(tk.Frame):
    def __init__(self, pai, fundo):
        super().__init__(pai, bg=fundo)
        self.canvas = tk.Canvas(self, bg=fundo, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.corpo = tk.Frame(self.canvas, bg=fundo)
        self.janela = self.canvas.create_window((0, 0), window=self.corpo, anchor="nw")
        self.corpo.bind(
            "<Configure>",
            lambda _: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self.janela, width=e.width),
        )

    def rolar(self, delta):
        if self.corpo.winfo_reqheight() > self.canvas.winfo_height():
            self.canvas.yview_scroll(int(-delta / 120), "units")

    def limpar(self):
        for filho in self.corpo.winfo_children():
            filho.destroy()
        self.canvas.yview_moveto(0)


class JoviLens:
    def __init__(self, raiz):
        self.raiz = raiz
        self.config = carregar_config()
        self.token = GerenciadorToken(
            self.config["ml_client_id"], self.config["ml_client_secret"]
        )
        self.dados = carregar_dados()
        self.resultados = []
        self.resumo_radar = {}
        self.filtro_resultados = 0
        self.rotulos_link = {}
        self.fila = queue.Queue()
        self.camera = None
        self.imagem_congelada = None
        self.foto_tk = None
        self.analisando = False
        self.servidor = None
        self.indice_camera = tk.StringVar(value="0")
        self.quadros = deque(maxlen=10)
        self.monitorando = tk.BooleanVar(value=False)
        self.termo = tk.StringVar()
        self.status = tk.StringVar(value="Menu principal. Escolha uma opção.")
        self.num_favoritos = tk.StringVar(value="0")
        self.num_alertas = tk.StringVar(value="0")
        self.radar_melhor = tk.StringVar()
        self.radar_loja = tk.StringVar()
        self.radar_detalhe = tk.StringVar()
        self.pagina_atual = ""
        self.paginas = {}
        self.areas = {}
        self.itens_nav = {}
        self.chips_filtro = []

        self.configurar_janela()
        self.criar_menu()
        self.criar_pagina_buscar()
        self.criar_pagina_resultados()
        self.criar_pagina_favoritos()
        self.criar_pagina_alertas()
        self.atualizar_radar({})
        self.atualizar_tabela_favoritos()
        self.atualizar_lista_alertas()
        self.mostrar_pagina("menu")
        self.raiz.bind("<Key>", self.tecla_menu)
        self.raiz.bind_all("<MouseWheel>", lambda e: self.rolar_pagina(e.delta))
        self.raiz.bind_all("<Button-4>", lambda e: self.rolar_pagina(120))
        self.raiz.bind_all("<Button-5>", lambda e: self.rolar_pagina(-120))
        self.raiz.protocol("WM_DELETE_WINDOW", self.encerrar)
        self.raiz.after(100, self.processar_fila)
        self.mostrar_estado_inicial()

    def configurar_janela(self):
        self.raiz.title("Jovi Lens")
        altura = max(640, min(880, self.raiz.winfo_screenheight() - 90))
        posicao_x = max(0, (self.raiz.winfo_screenwidth() - LARGURA_APP) // 2)
        self.raiz.geometry(f"{LARGURA_APP}x{altura}+{posicao_x}+20")
        self.raiz.minsize(400, 620)
        self.raiz.configure(bg=COR_FUNDO)

        self.barra_app = tk.Frame(self.raiz, bg=COR_FUNDO)
        self.barra_app.pack(side="top", fill="x", padx=16, pady=(14, 8))
        self.botao_voltar = BotaoModerno(
            self.barra_app,
            "‹  Menu",
            self.voltar_ao_menu,
            largura=88,
            altura=34,
            raio=17,
        )
        self.titulo_app = tk.Label(
            self.barra_app,
            text="",
            bg=COR_FUNDO,
            fg=COR_TEXTO,
            font=(FONTE, 16, "bold"),
        )
        self.titulo_app.pack(side="left")

        self.criar_barra_navegacao()
        tk.Label(
            self.raiz,
            textvariable=self.status,
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
            wraplength=LARGURA_APP - 40,
            justify="left",
            anchor="w",
            height=2,
        ).pack(side="bottom", fill="x", padx=16, pady=(2, 4))
        self.container = tk.Frame(self.raiz, bg=COR_FUNDO)
        self.container.pack(side="top", fill="both", expand=True)

    def criar_barra_navegacao(self):
        barra = tk.Frame(self.raiz, bg=COR_NAV)
        barra.pack(side="bottom", fill="x")
        itens = [
            ("menu", "⌂", "Início", self.voltar_ao_menu),
            ("buscar", "📷", "Escanear", self.opcao_escanear),
            ("favoritos", "★", "Favoritos", self.opcao_favoritos),
            ("alertas", "🔔", "Alertas", self.opcao_alertas),
            ("celular", "📱", "Celular", self.abrir_modo_celular),
        ]
        for coluna, (chave, icone, texto, comando) in enumerate(itens):
            barra.columnconfigure(coluna, weight=1, uniform="nav")
            item = tk.Frame(barra, bg=COR_NAV)
            item.grid(row=0, column=coluna, sticky="nsew", pady=(8, 8))
            rotulo_icone = tk.Label(
                item, text=icone, bg=COR_NAV, fg=COR_SUAVE, font=(FONTE_EMOJI, 15)
            )
            rotulo_texto = tk.Label(
                item, text=texto, bg=COR_NAV, fg=COR_SUAVE, font=(FONTE, 8, "bold")
            )
            rotulo_icone.pack()
            rotulo_texto.pack()
            tornar_clicavel(item, comando)
            self.itens_nav[chave] = (rotulo_icone, rotulo_texto)

    def destacar_navegacao(self, nome):
        ativo = "buscar" if nome == "resultados" else nome
        for chave, (rotulo_icone, rotulo_texto) in self.itens_nav.items():
            cor = COR_DESTAQUE if chave == ativo else COR_SUAVE
            rotulo_icone.configure(fg=cor)
            rotulo_texto.configure(fg=cor)

    def criar_area(self, nome):
        area = AreaRolavel(self.container, COR_FUNDO)
        self.paginas[nome] = area
        self.areas[nome] = area
        return area.corpo

    def criar_pagina_mista(self, nome):
        pagina = tk.Frame(self.container, bg=COR_FUNDO)
        topo = tk.Frame(pagina, bg=COR_FUNDO)
        topo.pack(fill="x", padx=16, pady=(0, 8))
        area = AreaRolavel(pagina, COR_FUNDO)
        area.pack(fill="both", expand=True)
        self.paginas[nome] = pagina
        self.areas[nome] = area
        return topo

    def mostrar_pagina(self, nome):
        for pagina in self.paginas.values():
            pagina.pack_forget()
        self.paginas[nome].pack(fill="both", expand=True)
        self.pagina_atual = nome
        self.titulo_app.configure(
            text=TITULOS_PAGINAS[nome], fg=COR_DESTAQUE if nome == "menu" else COR_TEXTO
        )
        if nome == "menu":
            self.botao_voltar.pack_forget()
            self.atualizar_resumo_menu()
        else:
            self.botao_voltar.pack(side="left", padx=(0, 12), before=self.titulo_app)
        self.destacar_navegacao(nome)

    def rolar_pagina(self, delta):
        area = self.areas.get(self.pagina_atual)
        if area is not None:
            area.rolar(delta)

    def voltar_ao_menu(self):
        self.parar_camera()
        self.mostrar_pagina("menu")
        self.status.set("Menu principal. Escolha uma opção.")

    def mostrar_estado_inicial(self):
        if cv2 is None:
            self.status.set("OpenCV não instalado: use a Galeria ou o modo celular.")
        elif not ocr_disponivel():
            self.status.set(
                "OCR não encontrado. Rode: python -m pip install rapidocr-onnxruntime"
            )

    def criar_menu(self):
        corpo = self.criar_area("menu")
        tk.Label(
            corpo, text="Olá! 👋", bg=COR_FUNDO, fg=COR_TEXTO, font=(FONTE, 22, "bold")
        ).pack(anchor="w", padx=16, pady=(2, 0))
        tk.Label(
            corpo,
            text="O que você quer fazer hoje?",
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 11),
        ).pack(anchor="w", padx=16, pady=(0, 12))

        heroi = Cartao(corpo, cor=COR_DESTAQUE, raio=24, margem=18)
        heroi.pack(fill="x", padx=16, pady=(0, 12))
        tk.Label(
            heroi.interno,
            text="Escaneie um produto",
            bg=COR_DESTAQUE,
            fg="white",
            font=(FONTE, 16, "bold"),
            anchor="w",
        ).pack(anchor="w")
        tk.Label(
            heroi.interno,
            text="Aponte a câmera e compare preços reais em segundos.",
            bg=COR_DESTAQUE,
            fg="#dbe7ff",
            font=(FONTE, 10),
            wraplength=320,
            justify="left",
        ).pack(anchor="w", pady=(2, 12))
        BotaoModerno(
            heroi.interno,
            "📷  Escanear agora",
            self.opcao_escanear,
            cor="white",
            cor_texto=COR_DESTAQUE,
            cor_hover="#e8f0ff",
            largura=180,
            altura=40,
            raio=20,
        ).pack(anchor="w")

        estatisticas = tk.Frame(corpo, bg=COR_FUNDO)
        estatisticas.pack(fill="x", padx=16, pady=(0, 8))
        for coluna, (variavel, rotulo, comando) in enumerate(
            (
                (self.num_favoritos, "Favoritos", self.opcao_favoritos),
                (self.num_alertas, "Alertas", self.opcao_alertas),
            )
        ):
            estatisticas.columnconfigure(coluna, weight=1, uniform="estatisticas")
            cartao = Cartao(estatisticas, margem=12)
            cartao.grid(
                row=0,
                column=coluna,
                sticky="ew",
                padx=(0, 6) if coluna == 0 else (6, 0),
            )
            tk.Label(
                cartao.interno,
                textvariable=variavel,
                bg=COR_CARTAO,
                fg=COR_TEXTO,
                font=(FONTE, 20, "bold"),
            ).pack(anchor="w")
            tk.Label(
                cartao.interno,
                text=rotulo,
                bg=COR_CARTAO,
                fg=COR_SUAVE,
                font=(FONTE, 9),
            ).pack(anchor="w")
            tornar_clicavel(cartao, comando)

        tk.Label(
            corpo,
            text="Menu principal",
            bg=COR_FUNDO,
            fg=COR_TEXTO,
            font=(FONTE, 12, "bold"),
        ).pack(anchor="w", padx=16, pady=(10, 4))
        self.opcoes_menu = {
            "1": ("Escanear produto com a câmera", self.opcao_escanear),
            "2": ("Buscar produto pelo nome", self.opcao_buscar_nome),
            "3": ("Meus favoritos", self.opcao_favoritos),
            "4": ("Verificar promoções agora", self.opcao_verificar_promocoes),
            "5": ("Histórico de alertas", self.opcao_alertas),
            "6": ("Modo celular: usar a câmera do celular", self.abrir_modo_celular),
            "0": ("Sair", self.sair),
        }
        grade = tk.Frame(corpo, bg=COR_FUNDO)
        grade.pack(fill="x", padx=16)
        for coluna in (0, 1):
            grade.columnconfigure(coluna, weight=1, uniform="grade")
        for posicao, numero in enumerate(("1", "2", "3", "4", "5", "6")):
            texto, comando = self.opcoes_menu[numero]
            cartao = Cartao(grade, margem=14)
            cartao.grid(
                row=posicao // 2,
                column=posicao % 2,
                sticky="nsew",
                pady=5,
                padx=(0, 6) if posicao % 2 == 0 else (6, 0),
            )
            topo = tk.Frame(cartao.interno, bg=COR_CARTAO)
            topo.pack(fill="x")
            tk.Label(
                topo,
                text=ICONES_MENU[numero],
                bg=COR_CARTAO,
                fg=COR_TEXTO,
                font=(FONTE_EMOJI, 20),
            ).pack(side="left")
            tk.Label(
                topo, text=numero, bg=COR_CARTAO, fg=COR_SUAVE, font=(FONTE, 10, "bold")
            ).pack(side="right")
            tk.Label(
                cartao.interno,
                text=texto,
                bg=COR_CARTAO,
                fg=COR_TEXTO,
                font=(FONTE, 10, "bold"),
                wraplength=140,
                justify="left",
                anchor="nw",
                height=3,
            ).pack(fill="x", pady=(8, 0))
            tornar_clicavel(cartao, comando)
        BotaoModerno(
            corpo,
            "0   ·   Sair",
            self.sair,
            cor="#3b1220",
            cor_texto="#fca5a5",
            cor_hover="#4c1a2b",
            altura=46,
        ).pack(fill="x", padx=16, pady=(12, 4))
        tk.Label(
            corpo,
            text="Dica: você também pode digitar o número da opção no teclado.",
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
        ).pack(pady=(4, 14))

    def tecla_menu(self, evento):
        if self.pagina_atual == "menu" and evento.char in self.opcoes_menu:
            self.opcoes_menu[evento.char][1]()

    def atualizar_resumo_menu(self):
        self.num_favoritos.set(str(len(self.dados["favoritos"])))
        self.num_alertas.set(str(len(self.dados["alertas"])))

    def opcao_escanear(self):
        self.mostrar_pagina("buscar")
        if cv2 is not None and self.camera is None:
            self.alternar_camera()

    def opcao_buscar_nome(self):
        self.parar_camera()
        self.mostrar_pagina("buscar")
        self.campo_busca.focus_set()
        self.status.set(
            "Digite o nome do produto e pressione Enter para buscar os preços."
        )

    def opcao_favoritos(self):
        self.parar_camera()
        self.mostrar_pagina("favoritos")
        self.status.set(
            "Acompanhe seus favoritos, defina preço alvo e atualize os preços."
        )

    def opcao_alertas(self):
        self.parar_camera()
        self.mostrar_pagina("alertas")

    def opcao_verificar_promocoes(self):
        if not self.dados["favoritos"]:
            messagebox.showinfo(
                "Verificar promoções",
                "Você ainda não tem favoritos.\nUse a opção 1 ou 2 para buscar produtos e favoritá-los.",
            )
            return
        self.atualizar_precos()

    def sair(self):
        if messagebox.askyesno("Sair", "Deseja realmente encerrar o Jovi Lens?"):
            self.encerrar()

    def criar_estado_vazio(
        self, pai, icone, titulo, texto, rotulo_botao=None, comando=None
    ):
        cartao = Cartao(pai, margem=24)
        cartao.pack(fill="x", padx=16, pady=10)
        tk.Label(
            cartao.interno,
            text=icone,
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE_EMOJI, 28),
        ).pack()
        tk.Label(
            cartao.interno,
            text=titulo,
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 12, "bold"),
        ).pack(pady=(6, 2))
        tk.Label(
            cartao.interno,
            text=texto,
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 10),
            wraplength=300,
            justify="center",
        ).pack()
        if rotulo_botao:
            BotaoModerno(
                cartao.interno,
                rotulo_botao,
                comando,
                cor=COR_DESTAQUE,
                largura=200,
                altura=40,
                raio=20,
            ).pack(pady=(14, 0))

    def criar_pagina_buscar(self):
        corpo = self.criar_area("buscar")
        self.canvas = tk.Canvas(
            corpo,
            width=LARGURA_VISOR,
            height=ALTURA_VISOR,
            bg="#05070d",
            highlightthickness=0,
            bd=0,
        )
        self.canvas.pack(padx=16, pady=(0, 10))
        self.desenhar_visor_vazio()

        controles = tk.Frame(corpo, bg=COR_FUNDO)
        controles.pack(fill="x", padx=16)
        for coluna, peso in enumerate((2, 3, 2)):
            controles.columnconfigure(coluna, weight=peso, uniform="controles")
        self.botao_camera = BotaoModerno(
            controles, "▶  Câmera", self.alternar_camera, altura=48, raio=24
        )
        self.botao_camera.grid(row=0, column=0, sticky="ew", padx=(0, 6))
        BotaoModerno(
            controles,
            "●  Escanear",
            self.escanear,
            cor=COR_DESTAQUE,
            altura=48,
            raio=24,
        ).grid(row=0, column=1, sticky="ew", padx=3)
        BotaoModerno(
            controles, "🖼  Galeria", self.abrir_imagem, altura=48, raio=24
        ).grid(row=0, column=2, sticky="ew", padx=(6, 0))

        seletor = tk.Frame(corpo, bg=COR_FUNDO)
        seletor.pack(fill="x", padx=18, pady=(8, 4))
        tk.Label(
            seletor, text="Câmera nº", bg=COR_FUNDO, fg=COR_SUAVE, font=(FONTE, 9)
        ).pack(side="left")
        tk.Spinbox(
            seletor,
            from_=0,
            to=5,
            width=3,
            textvariable=self.indice_camera,
            wrap=True,
            state="readonly",
            bg=COR_ELEVADO,
            fg=COR_TEXTO,
            relief="flat",
            buttonbackground=COR_ELEVADO,
            readonlybackground=COR_ELEVADO,
        ).pack(side="left", padx=6)

        cartao = Cartao(corpo, margem=14)
        cartao.pack(fill="x", padx=16, pady=(8, 6))
        tk.Label(
            cartao.interno,
            text="Item identificado ou o que você quer buscar",
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
        ).pack(anchor="w", pady=(0, 6))
        linha = tk.Frame(cartao.interno, bg=COR_CARTAO)
        linha.pack(fill="x")
        self.campo_busca = tk.Entry(
            linha,
            textvariable=self.termo,
            bg=COR_ELEVADO,
            fg=COR_TEXTO,
            insertbackground=COR_TEXTO,
            relief="flat",
            font=(FONTE, 12),
            highlightthickness=0,
        )
        self.campo_busca.pack(side="left", fill="x", expand=True, ipady=9, padx=(0, 8))
        self.campo_busca.bind("<Return>", lambda _: self.buscar())
        BotaoModerno(
            linha,
            "Buscar",
            self.buscar,
            cor=COR_DESTAQUE,
            largura=86,
            altura=40,
            raio=12,
        ).pack(side="right")

        self.area_hipoteses = tk.Frame(corpo, bg=COR_FUNDO)
        self.area_hipoteses.pack(fill="x", padx=18, pady=(4, 12))

    def desenhar_moldura(self):
        margem, comprimento = 16, 34
        for x, y, dx, dy in (
            (margem, margem, 1, 1),
            (LARGURA_VISOR - margem, margem, -1, 1),
            (margem, ALTURA_VISOR - margem, 1, -1),
            (LARGURA_VISOR - margem, ALTURA_VISOR - margem, -1, -1),
        ):
            self.canvas.create_line(
                x,
                y + dy * comprimento,
                x,
                y,
                x + dx * comprimento,
                y,
                fill=COR_DESTAQUE,
                width=4,
                capstyle="round",
                joinstyle="round",
            )

    def desenhar_visor_vazio(self):
        self.canvas.delete("all")
        self.canvas.create_text(
            LARGURA_VISOR / 2,
            ALTURA_VISOR / 2,
            text="Visor da câmera Jovi\nInicie a câmera ou escolha uma imagem",
            fill=COR_SUAVE,
            justify="center",
            font=(FONTE, 11),
        )
        self.desenhar_moldura()

    def criar_pagina_resultados(self):
        topo = self.criar_pagina_mista("resultados")
        cartao = Cartao(topo, margem=14)
        cartao.pack(fill="x", pady=(0, 8))
        tk.Label(
            cartao.interno,
            text="RADAR JOVI",
            bg=COR_CARTAO,
            fg=COR_DESTAQUE,
            font=(FONTE, 8, "bold"),
        ).pack(anchor="w")
        tk.Label(
            cartao.interno,
            textvariable=self.radar_melhor,
            bg=COR_CARTAO,
            fg=COR_SUCESSO,
            font=(FONTE, 15, "bold"),
            anchor="w",
            wraplength=350,
            justify="left",
        ).pack(anchor="w", pady=(2, 0))
        tk.Label(
            cartao.interno,
            textvariable=self.radar_loja,
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 10),
            anchor="w",
            wraplength=350,
            justify="left",
        ).pack(anchor="w")
        tk.Label(
            cartao.interno,
            textvariable=self.radar_detalhe,
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
            anchor="w",
            wraplength=350,
            justify="left",
        ).pack(anchor="w", pady=(6, 0))
        linha = tk.Frame(topo, bg=COR_FUNDO)
        linha.pack(fill="x")
        self.chips_filtro = []
        for indice, (rotulo, _) in enumerate(FILTROS_RESULTADOS):
            chip = Chip(
                linha,
                rotulo,
                lambda i=indice: self.definir_filtro(i),
                ativo=indice == 0,
            )
            chip.pack(side="left", padx=(0, 6))
            self.chips_filtro.append(chip)
        Chip(linha, "Nova busca", lambda: self.mostrar_pagina("buscar")).pack(
            side="right"
        )

    def atualizar_radar(self, resumo):
        if not resumo:
            self.radar_melhor.set("Faça uma busca")
            self.radar_loja.set(
                "Escaneie ou digite um produto para analisar os preços."
            )
            self.radar_detalhe.set("")
            return
        self.radar_melhor.set(
            f"★ Melhor preço  {formatar_preco(resumo['menor_preco'])}"
        )
        self.radar_loja.set(f"em {resumo['menor_loja']}")
        detalhe = (
            f"{resumo['total']} ofertas  •  mediana {formatar_preco(resumo['mediana'])}  •  "
            f"maior {formatar_preco(resumo['maior_preco'])}"
        )
        if resumo["suspeitas"]:
            detalhe += f"  •  {resumo['suspeitas']} para verificar"
        self.radar_detalhe.set(detalhe)

    def definir_filtro(self, indice):
        self.filtro_resultados = indice
        for posicao, chip in enumerate(self.chips_filtro):
            chip.definir_ativo(posicao == indice)
        self.renderizar_resultados()

    def renderizar_resultados(self):
        area = self.areas["resultados"]
        area.limpar()
        self.rotulos_link = {}
        permitidos = FILTROS_RESULTADOS[self.filtro_resultados][1]
        itens = [
            p for p in self.resultados if permitidos is None or p["selo"] in permitidos
        ]
        if not itens:
            self.criar_estado_vazio(
                area.corpo,
                "🔍",
                "Nada por aqui",
                "Nenhuma oferta nesta categoria. Tente outro filtro ou faça uma nova busca.",
            )
            return
        for produto in itens:
            self.criar_cartao_resultado(area.corpo, produto)

    def criar_cartao_resultado(self, pai, produto):
        cor_selo = CORES_SELO.get(TAGS_SELO.get(produto["selo"], ""), COR_TEXTO)
        cartao = Cartao(pai, margem=14)
        cartao.pack(fill="x", padx=16, pady=6)
        conteudo = cartao.interno
        topo = tk.Frame(conteudo, bg=COR_CARTAO)
        topo.pack(fill="x")
        tk.Label(
            topo,
            text=produto["selo"],
            bg=COR_ELEVADO,
            fg=cor_selo,
            font=(FONTE, 9, "bold"),
            padx=10,
            pady=3,
        ).pack(side="left")
        tk.Label(
            topo,
            text=f"{produto['vs_texto']} vs. mediana",
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
        ).pack(side="right")
        tk.Label(
            conteudo,
            text=produto["titulo"],
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 10, "bold"),
            wraplength=340,
            justify="left",
            anchor="w",
        ).pack(fill="x", pady=(8, 4))
        linha = tk.Frame(conteudo, bg=COR_CARTAO)
        linha.pack(fill="x")
        tk.Label(
            linha,
            text=formatar_preco(produto["preco"]),
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 17, "bold"),
        ).pack(side="left")
        tk.Label(
            linha, text=produto["loja"], bg=COR_CARTAO, fg=COR_SUAVE, font=(FONTE, 9)
        ).pack(side="right")
        if produto["custo_texto"]:
            tk.Label(
                conteudo,
                text=f"Custo-benefício: {produto['custo_texto']}",
                bg=COR_CARTAO,
                fg=COR_SUAVE,
                font=(FONTE, 9),
                anchor="w",
            ).pack(fill="x")
        texto_link, cor_link = ROTULOS_LINK_LONGOS.get(
            produto.get("tipo_link"), ("", COR_SUAVE)
        )
        rotulo_link = tk.Label(
            conteudo,
            text=texto_link,
            bg=COR_CARTAO,
            fg=cor_link,
            font=(FONTE, 9),
            anchor="w",
        )
        rotulo_link.pack(fill="x", pady=(2, 8))
        self.rotulos_link[id(produto)] = rotulo_link

        botoes = tk.Frame(conteudo, bg=COR_CARTAO)
        botoes.pack(fill="x")
        for coluna in (0, 1):
            botoes.columnconfigure(coluna, weight=1, uniform="botoes")
        BotaoModerno(
            botoes,
            "Abrir anúncio",
            lambda p=produto: self.abrir_link_produto(p),
            altura=38,
            raio=12,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ja_favorito = any(fav["id"] == produto["id"] for fav in self.dados["favoritos"])
        botao = BotaoModerno(
            botoes,
            "★ Favoritado" if ja_favorito else "☆ Favoritar",
            None,
            cor=COR_ELEVADO if ja_favorito else COR_DESTAQUE,
            cor_texto=COR_OURO if ja_favorito else "white",
            altura=38,
            raio=12,
        )
        botao.comando = lambda p=produto, b=botao: self.favoritar_produto(p, b)
        botao.grid(row=0, column=1, sticky="ew", padx=(4, 0))

    def criar_pagina_favoritos(self):
        topo = self.criar_pagina_mista("favoritos")
        BotaoModerno(
            topo,
            "↻  Atualizar preços",
            self.atualizar_precos,
            cor=COR_DESTAQUE,
            altura=44,
            raio=22,
        ).pack(fill="x")
        tk.Checkbutton(
            topo,
            text="Monitorar automaticamente a cada 15 min",
            variable=self.monitorando,
            command=self.alternar_monitoramento,
            bg=COR_FUNDO,
            fg=COR_TEXTO,
            selectcolor=COR_ELEVADO,
            activebackground=COR_FUNDO,
            activeforeground=COR_TEXTO,
            font=(FONTE, 9),
            highlightthickness=0,
            bd=0,
        ).pack(anchor="w", pady=(8, 0))

    def atualizar_tabela_favoritos(self):
        area = self.areas["favoritos"]
        area.limpar()
        if not self.dados["favoritos"]:
            self.criar_estado_vazio(
                area.corpo,
                "☆",
                "Nenhum favorito ainda",
                "Escaneie ou busque um produto e toque em Favoritar para acompanhar o preço.",
                "Escanear produto",
                self.opcao_escanear,
            )
        for fav in self.dados["favoritos"]:
            self.criar_cartao_favorito(area.corpo, fav)
        self.atualizar_resumo_menu()

    def criar_cartao_favorito(self, pai, fav):
        inicial = fav.get("preco_inicial") or 0
        atual = fav.get("preco_atual") or 0
        variacao = (atual - inicial) / inicial * 100 if inicial else 0.0
        cor_variacao = (
            COR_SUCESSO if variacao < 0 else (COR_PERIGO if variacao > 0 else COR_SUAVE)
        )
        alvo = fav.get("preco_alvo")
        cartao = Cartao(pai, margem=14)
        cartao.pack(fill="x", padx=16, pady=6)
        conteudo = cartao.interno
        tk.Label(
            conteudo,
            text=fav["titulo"],
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 10, "bold"),
            wraplength=340,
            justify="left",
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            conteudo,
            text=fav.get("loja", ""),
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
            anchor="w",
        ).pack(fill="x")
        linha = tk.Frame(conteudo, bg=COR_CARTAO)
        linha.pack(fill="x", pady=(6, 2))
        tk.Label(
            linha,
            text=formatar_preco(atual),
            bg=COR_CARTAO,
            fg=COR_TEXTO,
            font=(FONTE, 17, "bold"),
        ).pack(side="left")
        tk.Label(
            linha,
            text=f"{variacao:+.1f}%",
            bg=COR_ELEVADO,
            fg=cor_variacao,
            font=(FONTE, 9, "bold"),
            padx=10,
            pady=3,
        ).pack(side="right")
        alvo_texto = formatar_preco(alvo) if alvo else "não definido"
        tk.Label(
            conteudo,
            text=f"Inicial {formatar_preco(inicial)}   •   Alvo {alvo_texto}",
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
            anchor="w",
        ).pack(fill="x")
        tk.Label(
            conteudo,
            text=gerar_tendencia(fav.get("historico", []), atual),
            bg=COR_CARTAO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
            anchor="w",
        ).pack(fill="x", pady=(0, 8))
        botoes = tk.Frame(conteudo, bg=COR_CARTAO)
        botoes.pack(fill="x")
        for coluna in (0, 1, 2):
            botoes.columnconfigure(coluna, weight=1, uniform="botoes")
        BotaoModerno(
            botoes,
            "Abrir",
            lambda f=fav: self.abrir_link_favorito(f),
            altura=36,
            raio=12,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 3))
        BotaoModerno(
            botoes, "Preço alvo", lambda f=fav: self.definir_alvo(f), altura=36, raio=12
        ).grid(row=0, column=1, sticky="ew", padx=3)
        BotaoModerno(
            botoes,
            "Remover",
            lambda f=fav: self.remover_favorito(f),
            cor="#3b1220",
            cor_texto="#fca5a5",
            altura=36,
            raio=12,
        ).grid(row=0, column=2, sticky="ew", padx=(3, 0))

    def criar_pagina_alertas(self):
        topo = self.criar_pagina_mista("alertas")
        BotaoModerno(
            topo, "Limpar alertas", self.limpar_alertas, altura=40, raio=20
        ).pack(fill="x")

    def atualizar_lista_alertas(self):
        area = self.areas["alertas"]
        area.limpar()
        if not self.dados["alertas"]:
            self.criar_estado_vazio(
                area.corpo,
                "🔔",
                "Sem alertas por enquanto",
                "Quando um favorito atingir o preço alvo ou cair 5% ou mais, avisaremos aqui.",
            )
        for alerta in self.dados["alertas"]:
            cartao = Cartao(area.corpo, margem=14)
            cartao.pack(fill="x", padx=16, pady=5)
            linha = tk.Frame(cartao.interno, bg=COR_CARTAO)
            linha.pack(fill="x")
            tk.Label(
                linha, text="🔔", bg=COR_CARTAO, fg=COR_OURO, font=(FONTE_EMOJI, 16)
            ).pack(side="left", anchor="n")
            texto = tk.Frame(linha, bg=COR_CARTAO)
            texto.pack(side="left", fill="x", expand=True, padx=(10, 0))
            tk.Label(
                texto,
                text=alerta["mensagem"],
                bg=COR_CARTAO,
                fg=COR_TEXTO,
                font=(FONTE, 10),
                wraplength=300,
                justify="left",
                anchor="w",
            ).pack(fill="x")
            tk.Label(
                texto,
                text=alerta["data"],
                bg=COR_CARTAO,
                fg=COR_SUAVE,
                font=(FONTE, 8),
                anchor="w",
            ).pack(fill="x", pady=(2, 0))
        self.atualizar_resumo_menu()

    def limpar_alertas(self):
        if not self.dados["alertas"]:
            messagebox.showinfo("Alertas", "Não há alertas para apagar.")
            return
        if not messagebox.askyesno("Alertas", "Apagar todo o histórico de alertas?"):
            return
        self.dados["alertas"] = []
        self.salvar()
        self.atualizar_lista_alertas()

    def executar_em_thread(self, tarefa, ao_concluir):
        def trabalho():
            try:
                resultado = (True, tarefa())
            except Exception as erro:
                resultado = (False, erro)
            self.fila.put((ao_concluir, resultado))

        threading.Thread(target=trabalho, daemon=True).start()

    def processar_fila(self):
        try:
            while True:
                funcao, resultado = self.fila.get_nowait()
                funcao(*resultado)
        except queue.Empty:
            pass
        self.raiz.after(100, self.processar_fila)

    def alternar_camera(self):
        if self.camera is not None:
            self.parar_camera()
            return
        if cv2 is None:
            messagebox.showwarning(
                "Câmera",
                "Instale o OpenCV (pip install opencv-python) ou use a Galeria.",
            )
            return
        try:
            captura = cv2.VideoCapture(int(self.indice_camera.get()))
            if not captura.isOpened():
                captura.release()
                raise RuntimeError("Nenhuma câmera disponível.")
        except Exception as erro:
            messagebox.showerror("Câmera", f"Não foi possível abrir a câmera.\n{erro}")
            return
        self.camera = captura
        self.imagem_congelada = None
        self.quadros.clear()
        self.botao_camera.configurar_texto("■  Parar")
        self.status.set("Câmera ativa. Aponte para o item e toque em Escanear.")
        self.atualizar_quadro()

    def parar_camera(self):
        if self.camera is not None:
            self.camera.release()
            self.camera = None
        self.botao_camera.configurar_texto("▶  Câmera")

    def atualizar_quadro(self):
        if self.camera is None or self.imagem_congelada is not None:
            return
        try:
            sucesso, quadro = self.camera.read()
            if sucesso:
                imagem = Image.fromarray(cv2.cvtColor(quadro, cv2.COLOR_BGR2RGB))
                nitidez = cv2.Laplacian(
                    cv2.cvtColor(quadro, cv2.COLOR_BGR2GRAY), cv2.CV_64F
                ).var()
                self.quadros.append((nitidez, imagem))
                self.exibir_imagem(imagem)
        except Exception:
            self.parar_camera()
            self.status.set("Falha na leitura da câmera.")
            return
        self.raiz.after(33, self.atualizar_quadro)

    def exibir_imagem(self, imagem):
        copia = imagem.copy()
        copia.thumbnail((LARGURA_VISOR, ALTURA_VISOR))
        self.foto_tk = ImageTk.PhotoImage(copia)
        self.canvas.delete("all")
        self.canvas.create_image(
            LARGURA_VISOR / 2, ALTURA_VISOR / 2, image=self.foto_tk
        )
        self.desenhar_moldura()

    def escanear(self):
        if self.camera is not None and self.quadros:
            self.imagem_congelada = max(self.quadros, key=lambda quadro: quadro[0])[
                1
            ].copy()
            self.parar_camera()
            self.exibir_imagem(self.imagem_congelada)
        if self.imagem_congelada is None:
            messagebox.showinfo(
                "Escanear", "Inicie a câmera ou escolha uma imagem da galeria primeiro."
            )
            return
        self.identificar_imagem(self.imagem_congelada)

    def abrir_imagem(self):
        caminho = filedialog.askopenfilename(
            title="Selecionar imagem",
            filetypes=[("Imagens", "*.png *.jpg *.jpeg *.bmp *.webp")],
        )
        if not caminho:
            return
        try:
            with Image.open(caminho) as arquivo:
                imagem = arquivo.convert("RGB")
        except (OSError, ValueError) as erro:
            messagebox.showerror("Imagem", f"Não foi possível abrir a imagem.\n{erro}")
            return
        self.parar_camera()
        self.imagem_congelada = imagem
        self.exibir_imagem(imagem)
        self.identificar_imagem(imagem)

    def identificar_imagem(self, imagem):
        if self.analisando:
            return
        self.analisando = True
        self.status.set("Analisando imagem... aguarde alguns segundos.")
        self.executar_em_thread(
            lambda: identificar_objeto(imagem, self.config), self.ao_identificar
        )

    def mostrar_hipoteses(self, alternativas):
        for filho in self.area_hipoteses.winfo_children():
            filho.destroy()
        if not alternativas:
            return
        tk.Label(
            self.area_hipoteses,
            text="Não é esse? Toque em outra hipótese para buscar:",
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
        ).pack(anchor="w", pady=(0, 4))
        for hipotese in alternativas:
            rotulo = hipotese if len(hipotese) <= 30 else hipotese[:29] + "…"
            Chip(
                self.area_hipoteses, rotulo, lambda h=hipotese: self.usar_hipotese(h)
            ).pack(anchor="w", pady=2)

    def usar_hipotese(self, hipotese):
        self.termo.set(hipotese)
        self.buscar()

    def ao_identificar(self, sucesso, resultado):
        self.analisando = False
        if not sucesso:
            detalhe = (
                str(resultado)
                if isinstance(resultado, ErroIdentificacao)
                else f"{type(resultado).__name__}: {resultado}"
            )
            self.status.set(f"Falha ao identificar: {detalhe}")
            messagebox.showwarning("Escanear", detalhe)
            return
        texto, aviso, alternativas = resultado
        self.mostrar_hipoteses(alternativas)
        if texto:
            self.termo.set(texto)
            self.buscar()
            if aviso:
                self.status.set(f"{aviso} Usado reconhecimento local.")
        else:
            motivo = f" {aviso}" if aviso else ""
            self.status.set(
                "Não foi possível identificar. Aproxime o item ou digite o nome e toque em Buscar."
                + motivo
            )

    def buscar(self):
        termo = self.termo.get().strip()
        if not termo:
            messagebox.showinfo("Busca", "Digite ou escaneie um item para buscar.")
            return
        if len(termo) > 100:
            messagebox.showwarning(
                "Busca", "O termo de busca deve ter no máximo 100 caracteres."
            )
            return
        self.status.set(f"Buscando preços de '{termo}'...")
        self.executar_em_thread(
            lambda: buscar_e_analisar(termo, self.config, self.token), self.ao_buscar
        )

    def ao_buscar(self, sucesso, resultado):
        if not sucesso:
            self.status.set("Busca não concluída.")
            messagebox.showerror("Busca", str(resultado))
            return
        self.parar_camera()
        self.resultados, self.resumo_radar = resultado
        self.atualizar_radar(self.resumo_radar)
        self.definir_filtro(0)
        self.mostrar_pagina("resultados")
        self.status.set(f"{len(self.resultados)} resultado(s) encontrado(s).")

    def abrir_link_produto(self, produto):
        if produto.get("tipo_link") == "direto":
            webbrowser.open(produto["link"])
            return
        self.status.set("Procurando o anúncio na loja...")
        self.executar_em_thread(
            lambda: obter_link_loja(produto, self.config),
            lambda sucesso, resultado: self.ao_obter_link(produto, sucesso, resultado),
        )

    def ao_obter_link(self, produto, sucesso, resultado):
        if not sucesso:
            self.status.set("Não foi possível localizar o link da loja.")
            return
        link, tipo, aviso = resultado
        produto["link"], produto["tipo_link"] = link, tipo
        rotulo = self.rotulos_link.get(id(produto))
        if rotulo is not None:
            texto, cor = ROTULOS_LINK_LONGOS.get(tipo, ("", COR_SUAVE))
            try:
                rotulo.configure(text=texto, fg=cor)
            except tk.TclError:
                pass
        if any(item is produto for item in self.dados["favoritos"]):
            self.salvar()
        if tipo == "direto":
            self.status.set("Abrindo o anúncio na loja.")
            webbrowser.open(link)
            return
        self.status.set(aviso or "Anúncio direto não localizado.")
        if messagebox.askyesno(
            "Anúncio não localizado",
            f"Não consegui localizar o anúncio direto em {produto['loja']}.\n\n"
            "Abrir uma busca por este produto no Google Shopping?",
        ):
            webbrowser.open(link)

    def favoritar_produto(self, produto, botao):
        if any(fav["id"] == produto["id"] for fav in self.dados["favoritos"]):
            messagebox.showinfo("Favoritos", "Este produto já está nos favoritos.")
        else:
            self.dados["favoritos"].append(criar_favorito(produto))
            self.salvar()
            self.atualizar_tabela_favoritos()
            self.status.set("Produto adicionado aos favoritos.")
        botao.configurar_texto("★ Favoritado")
        botao.definir_cores(COR_ELEVADO, COR_OURO)

    def abrir_link_favorito(self, favorito):
        favorito["link"], favorito["tipo_link"] = classificar_link(
            favorito.get("link"), favorito["titulo"], favorito.get("loja", "")
        )
        self.abrir_link_produto(favorito)

    def definir_alvo(self, favorito):
        try:
            valor = simpledialog.askfloat(
                "Preço alvo",
                "Avisar quando o preço chegar a (R$):",
                parent=self.raiz,
                minvalue=0.01,
                maxvalue=1000000,
            )
        except tk.TclError:
            return
        if valor is None:
            return
        favorito["preco_alvo"] = float(valor)
        self.salvar()
        self.atualizar_tabela_favoritos()

    def remover_favorito(self, favorito):
        if messagebox.askyesno("Remover", "Remover este item dos favoritos?"):
            self.dados["favoritos"].remove(favorito)
            self.salvar()
            self.atualizar_tabela_favoritos()

    def atualizar_precos(self, silencioso=False):
        if not self.dados["favoritos"]:
            if not silencioso:
                messagebox.showinfo("Favoritos", "Nenhum favorito para atualizar.")
            return
        self.status.set("Atualizando preços dos favoritos... aguarde.")
        self.executar_em_thread(
            lambda: atualizar_todos_favoritos(self.dados, self.config, self.token),
            lambda sucesso, resultado: self.ao_atualizar_precos(
                sucesso, resultado, silencioso
            ),
        )

    def ao_atualizar_precos(self, sucesso, resultado, silencioso=False):
        if not sucesso:
            self.status.set("Falha ao atualizar preços.")
            if not silencioso:
                messagebox.showerror("Atualização", str(resultado))
            return
        novos_alertas, erros = resultado
        self.salvar()
        self.atualizar_tabela_favoritos()
        self.atualizar_lista_alertas()
        self.status.set(f"Preços atualizados às {agora_texto()}.")
        if novos_alertas:
            messagebox.showinfo(
                "Promoções encontradas",
                "\n\n".join(a["mensagem"] for a in novos_alertas),
            )
        elif not silencioso:
            detalhe = (
                f"\n\n{len(erros)} item(ns) não puderam ser atualizados."
                if erros
                else ""
            )
            messagebox.showinfo(
                "Verificar promoções",
                "Preços atualizados. Nenhuma promoção nova nos seus favoritos."
                + detalhe,
            )
        if erros and not novos_alertas:
            self.status.set(f"Atualizado com {len(erros)} falha(s): {erros[0]}")

    def alternar_monitoramento(self):
        if self.monitorando.get():
            self.status.set("Monitoramento automático ativado.")
            self.agendar_monitoramento()
        else:
            self.status.set("Monitoramento automático desativado.")

    def agendar_monitoramento(self):
        if not self.monitorando.get():
            return
        if self.dados["favoritos"]:
            self.atualizar_precos(silencioso=True)
        self.raiz.after(INTERVALO_MONITORAMENTO_MS, self.agendar_monitoramento)

    def abrir_modo_celular(self):
        if self.servidor is None:
            try:
                servidor = ServidorCelular(self)
                servidor.iniciar()
            except OSError as erro:
                messagebox.showerror(
                    "Modo celular", f"Não foi possível iniciar o servidor.\n{erro}"
                )
                return
            self.servidor = servidor
        url = self.servidor.url()
        janela = tk.Toplevel(self.raiz)
        janela.title("Modo celular")
        janela.configure(bg=COR_FUNDO)
        janela.resizable(False, False)
        tk.Label(
            janela,
            text="Use a câmera do celular",
            bg=COR_FUNDO,
            fg=COR_TEXTO,
            font=(FONTE, 15, "bold"),
        ).pack(padx=24, pady=(20, 4))
        tk.Label(
            janela,
            text="Conecte o celular na mesma rede Wi-Fi e aponte a câmera para o QR Code.",
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 10),
            wraplength=320,
            justify="center",
        ).pack(padx=24)
        qr = gerar_qrcode(url, 300)
        if qr is not None:
            janela.qr_tk = ImageTk.PhotoImage(qr)
            moldura = tk.Frame(janela, bg="white", padx=8, pady=8)
            moldura.pack(pady=14)
            tk.Label(moldura, image=janela.qr_tk, bg="white").pack()
        else:
            tk.Label(
                janela,
                text="Não foi possível gerar o QR Code. Digite o endereço abaixo no celular.",
                bg=COR_FUNDO,
                fg=COR_SUAVE,
                wraplength=320,
            ).pack(pady=12)
        campo = tk.Entry(
            janela,
            width=42,
            justify="center",
            bg=COR_ELEVADO,
            fg=COR_TEXTO,
            relief="flat",
            readonlybackground=COR_ELEVADO,
            font=(FONTE, 9),
        )
        campo.insert(0, url)
        campo.config(state="readonly")
        campo.pack(padx=24, pady=4, ipady=6)
        tk.Label(
            janela,
            text="O link contém uma senha temporária. Não o compartilhe.",
            bg=COR_FUNDO,
            fg=COR_SUAVE,
            font=(FONTE, 9),
        ).pack()
        barra = tk.Frame(janela, bg=COR_FUNDO)
        barra.pack(pady=16)
        BotaoModerno(
            barra,
            "Parar servidor",
            lambda: self.parar_servidor(janela),
            cor="#3b1220",
            cor_texto="#fca5a5",
            largura=140,
            altura=40,
            raio=20,
        ).pack(side="left", padx=6)
        BotaoModerno(
            barra,
            "Fechar",
            janela.destroy,
            cor=COR_DESTAQUE,
            largura=120,
            altura=40,
            raio=20,
        ).pack(side="left", padx=6)
        self.status.set("Modo celular ativo. Abra o link no navegador do celular.")

    def parar_servidor(self, janela=None):
        if self.servidor is not None:
            self.servidor.parar()
            self.servidor = None
        if janela is not None:
            janela.destroy()
        self.status.set("Modo celular encerrado.")

    def salvar(self):
        if not salvar_dados(self.dados):
            messagebox.showerror(
                "Salvar", "Não foi possível gravar o arquivo de dados."
            )

    def encerrar(self):
        self.parar_camera()
        if self.servidor is not None:
            self.servidor.parar()
        self.salvar()
        self.raiz.destroy()


def main():
    raiz = tk.Tk()
    JoviLens(raiz)
    raiz.mainloop()


if __name__ == "__main__":
    main()
